<?php /* Template Name: Тарифы Pro и Team */ defined( 'ABSPATH' ) || exit; get_header();

// Живые счётчики Pro-инвентаря: считаются по базе, а не вписываются руками.
// Кэш на 1 час, чтобы страница /pro/ не пересчитывала метаполя на каждом хите.
$stats = get_transient( 'hod_pro_stats' );
if ( ! is_array( $stats ) ) {
$stats = array( 'cards' => 0, 'pro_cards' => 0, 'ready_cards' => 0, 'branches' => 0, 'drills' => 0, 'templates' => 0, 'checks' => 0 );
if ( class_exists( 'WP_Query' ) ) {
	$q = new WP_Query( array( 'post_type' => 'situation', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => false ) );
	$stats['cards'] = (int) $q->found_posts;
	foreach ( $q->posts as $pid ) {
		if ( 'pro' === hod_meta( $pid, 'access_level', 'free' ) ) { $stats['pro_cards']++; }
		$st = function_exists( 'get_field' ) ? (string) get_field( 'pro_assets_status', $pid ) : (string) hod_meta( $pid, 'pro_assets_status' );
		if ( 'ready' === $st ) { $stats['ready_cards']++; }
		$c = hod_pro_counts( $pid );
		$stats['branches']  += $c['branches'];
		$stats['drills']    += $c['drills'];
		$stats['templates'] += $c['templates'];
		$stats['checks']    += $c['checklist'];
	}
}
	set_transient( 'hod_pro_stats', $stats, HOUR_IN_SECONDS );
}
?>
<div class="wrap" style="padding-top:34px;padding-bottom:48px">
	<div class="center" style="max-width:740px;margin:0 auto 30px">
		<h1 style="font-size:36px">Бесплатно - ситуации. В Pro - глубина</h1>
		<p class="lead muted" style="margin-top:12px">Мы не закрываем знания искусственно: видео, ошибка, приём, основной диалог и следующий шаг в бесплатных сериях открыты всегда. Платным делаем то, что экономит время на подготовке к конкретному разговору: развилки, тренажёр, шаблоны, чек-листы, экспорт и категорию «Управление персоналом».</p>
	</div>

	<div class="card pad" style="max-width:820px;margin:0 auto 30px">
		<div class="xs muted" style="text-transform:uppercase;letter-spacing:.09em;margin-bottom:10px">Что уже лежит в Pro (считается по базе, обновляется само)</div>
		<div class="grid g4">
			<div><b style="font-size:26px"><?php echo (int) $stats['branches']; ?></b><div class="small muted">развилок «если ответят иначе» в <?php echo (int) $stats['ready_cards']; ?> карточках с готовыми Pro-материалами</div></div>
			<div><b style="font-size:26px"><?php echo (int) $stats['drills']; ?></b><div class="small muted">заданий тренажёра с разбором</div></div>
			<div><b style="font-size:26px"><?php echo (int) $stats['templates']; ?></b><div class="small muted">готовых формулировок и писем</div></div>
			<div><b style="font-size:26px"><?php echo (int) $stats['checks']; ?></b><div class="small muted">пунктов чек-листов подготовки</div></div>
		</div>
		<p class="xs muted" style="margin-top:12px">Плюс 6 паков инструментов: последовательность 5 касаний, скрипт прохода фильтра, матрица обмена, письмо-фиксация, протокол торга, чек-лист первого экрана, регламент учёта каналов, план 90 дней и шаблон разбора записей. Две расчётные таблицы в xlsx: стоимость проблемы с окупаемостью и учёт каналов с ценой сделки и ROMI.</p>
	</div>

	<div class="price">
		<div class="card plan"><span class="badge b-free" style="align-self:flex-start">Free</span>
			<div class="amt">0 ₽</div><div class="small muted">Навсегда. Без регистрации.</div>
			<ul><li>Все видео и карточки бесплатных серий</li><li>Ситуация, ошибка, приём, основной диалог</li><li>Результат, следующий шаг, метрики</li><li>Источник и границы применимости</li><li>Поиск и фильтры</li><li>Одна развилка из трёх в видео (тизер)</li><li class="no">Все развилки диалога</li><li class="no">Тренажёр, шаблоны, чек-листы</li><li class="no">Экспорт и скачивание</li><li class="no">Категория «Управление персоналом»</li></ul>
			<a class="btn btn-o" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Открыть каталог</a></div>

		<div class="card plan hot"><span class="tag-hot">Старт: первый месяц 99 ₽</span><span class="badge b-pro" style="align-self:flex-start">Pro</span>
			<div class="amt">390 ₽<small>/мес · 3 900 ₽/год</small></div><div class="small muted">Для одного специалиста.</div>
			<ul><li>Всё из Free</li><li><b>Развилки диалога</b> - 3-5 сценариев в каждой карточке: отказ, отсрочка, давление, конкурент, другой собеседник, честный тупик</li><li><b>Тренажёр «выбери ответ»</b> - разбор верно / неверно / почему</li><li><b>Готовые формулировки</b>: письма, сообщения, фразы</li><li><b>Чек-листы подготовки</b> к разговору</li><li><b>6 паков инструментов</b> и 2 расчётные таблицы xlsx</li><li><b>Экспорт</b> карточки в Markdown и TXT (Notion), скачивание видео MP4</li><li><b>Категория «Управление персоналом»</b> с правовой рамкой ТК РФ</li><li>Личные подборки и сохранённые ситуации</li><li>Ранний доступ к новым сериям, еженедельный дайджест</li><li>Своя ситуация в производство: присылаете реплику - делаем карточку</li><li class="no">Командная аналитика и назначение карточек</li></ul>
			<?php echo do_shortcode( '[hod_buy level="pro" price="390" text="Попробовать за 99 ₽"]' ); ?>
			<div class="xs muted">Отмена и пауза в один клик. Возврат в течение 14 дней.</div></div>

		<div class="card plan"><span class="badge b-code" style="align-self:flex-start">Team</span>
			<div class="amt">4 900 ₽<small>/мес за 10 мест</small></div><div class="small muted">Для отдела продаж, маркетинга или HR.</div>
			<ul><li>Всё из Pro на каждое место</li><li>Рабочее пространство команды и общие подборки</li><li>Назначение карточек сотрудникам и отслеживание</li><li>Отчёт по тренажёру: какие развилки команда проваливает</li><li>Плейбуки под ваши серии сделок</li><li>Приоритетная поддержка и запрос ситуаций</li></ul>
			<a class="btn btn-d" href="<?php echo esc_url( home_url( '/podat-situaciyu/?team=1' ) ); ?>">Обсудить пилот</a>
			<div class="xs muted">От 30 мест - индивидуальные условия и своя библиотека по вашим записям.</div></div>
	</div>

	<div class="hr" style="margin:36px 0 26px"></div>
	<h2 id="packs" style="margin-bottom:8px">Что ещё можно купить отдельно, без подписки</h2>
	<p class="small muted" style="max-width:70ch">Пак - это ситуации одной темы и инструменты к ним: шаблоны, чек-листы, расчёты. Разовая покупка, доступ навсегда, обновление пака бесплатно.</p>
	<div class="grid g4" style="margin-top:16px">
		<?php
		$packs = array(
			array( 'PACK-FC', 'Первый контакт: 20 ситуаций', 'Последовательность 5 касаний, скрипт прохода фильтра, 3 шаблона писем.', '990 ₽' ),
			array( 'PACK-PR', 'Цена и скидка: 20 ситуаций', 'Матрица обмена, письмо-фиксация, калькулятор стоимости проблемы (xlsx).', '990 ₽' ),
			array( 'PACK-NG', 'Переговоры: 20 ситуаций', 'Протокол торга, работа с ультиматумом, вход при живом поставщике.', '1 490 ₽' ),
			array( 'PACK-PS', 'Позиционирование и текст', 'Два фильтра сообщения, протокол A/B-теста, чек-лист первого экрана.', '990 ₽' ),
			array( 'PACK-MKT', 'Маркетинг-аудит', 'Регламент учёта каналов, таблица с ценой сделки и ROMI, правило часа.', '990 ₽' ),
			array( 'PACK-PM', 'Управление персоналом: 40 ситуаций', 'План 90 дней, шаблон разбора записей, нормы ТК РФ с датой проверки.', '2 900 ₽' ),
			array( 'SVC', 'Разбор вашего отдела', '2 часа по вашим записям и процессам. Своя библиотека ситуаций.', 'от 45 000 ₽' ),
			array( 'CSF', 'Custom Scenario Factory', 'Оцифровка опыта компании в её библиотеку по записям звонков.', 'от 300 000 ₽' ),
		);
		foreach ( $packs as $p ) { echo '<div class="card pad"><span class="badge b-code">' . esc_html( $p[0] ) . '</span><h3 style="margin:10px 0 6px">' . esc_html( $p[1] ) . '</h3><p class="small muted">' . esc_html( $p[2] ) . '</p><b>' . esc_html( $p[3] ) . '</b></div>'; }
		?>
	</div>
	<div class="note" style="margin-top:22px"><b>Оплата.</b> Карты РФ - Robokassa или YooKassa (продавец - самозанятый, чек выдаётся автоматически). Донаты и поддержка - Boosty, VK Donut, Telegram Stars. Иностранные карты - на этапе запуска EN-версии.</div>

	<h2 style="margin:32px 0 12px">Частые вопросы</h2>
	<details class="hod-faq"><summary>Можно ли пользоваться без подписки?</summary><p class="small muted" style="margin-top:8px">Да. Видео, ситуации, ошибки, приёмы, основные диалоги и следующие шаги в бесплатных сериях открыты навсегда и без регистрации.</p></details>
	<details class="hod-faq"><summary>Что именно закрыто в Pro?</summary><p class="small muted" style="margin-top:8px">Развилки диалога (3-5 на карточку), тренажёр «выбери ответ», готовые формулировки, чек-листы подготовки, паки инструментов и расчётные таблицы, экспорт в Markdown и Notion, скачивание MP4, категория «Управление персоналом», личные подборки.</p></details>
	<details class="hod-faq"><summary>Сколько развилок в карточке?</summary><p class="small muted" style="margin-top:8px">Три минимум, в сложных переговорах и управлении - до пяти. Правило построения: одна развилка на самый вероятный ответ, одна на ответ, который меняет предмет разговора (другой собеседник, другой критерий), и одна на честный тупик - случай, когда приём применять нельзя и сделку нужно корректно закрыть.</p></details>
	<details class="hod-faq"><summary>В видео развилки есть?</summary><p class="small muted" style="margin-top:8px">Одна из трёх показывается в ролике как тизер. Остальные - в карточке на сайте, в Pro.</p></details>
	<details class="hod-faq"><summary>Почему «Управление персоналом» платная?</summary><p class="small muted" style="margin-top:8px">Карточки про управление людьми требуют проверки норм ТК РФ, кадровых документов и разбора записей. Это платная работа редактора и юриста. Две карточки в каждой серии остаются бесплатными, чтобы формат можно было проверить до оплаты.</p></details>
	<details class="hod-faq"><summary>Как отменить?</summary><p class="small muted" style="margin-top:8px">В один клик в личном кабинете или письмом. Есть пауза на 1-3 месяца вместо отмены. Возврат в течение 14 дней без объяснения причин.</p></details>
	<details class="hod-faq"><summary>Что если нужной ситуации нет в библиотеке?</summary><p class="small muted" style="margin-top:8px">Присылаете дословную реплику собеседника через форму «Прислать ситуацию». Подписчики Pro получают карточку в производство вне очереди и уведомление, когда она готова. Доступ к ней - навсегда, даже если подписка закончится.</p></details>
</div>
<?php get_footer(); ?>
