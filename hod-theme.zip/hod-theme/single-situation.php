<?php defined( 'ABSPATH' ) || exit; get_header();
while ( have_posts() ) : the_post();
$id   = get_the_ID();
$code = hod_meta( $id, 'code', $basename = $post->post_name );
$col  = hod_series_color( $id );
$ser  = hod_series( $id );
$pro  = 'pro' === hod_meta( $id, 'access_level', 'free' );
$gated = $pro && ! hod_is_pro(); // платная категория: гостю отдаются только видео, ситуация и ошибка
$line = hod_meta( $id, 'counterpart_line', get_the_title() );
$saved_ids = is_user_logged_in() ? array_map( 'absint', (array) get_user_meta( get_current_user_id(), 'hod_saved', true ) ) : array();
$is_saved = in_array( (int) $id, $saved_ids, true );
$g = function ( $k, $d = '' ) use ( $id ) { return function_exists( 'get_field' ) ? get_field( $k, $id ) : hod_meta( $id, $k, $d ); };
?>
<div class="wrap two" style="padding-top:26px;padding-bottom:50px;grid-template-columns:1fr 300px">
	<article class="article" style="max-width:none">
		<?php hod_breadcrumbs(); ?>
		<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
			<span class="badge b-code"><?php echo esc_html( $code ); ?></span>
			<span class="seriesdot" style="background:<?php echo esc_attr( $col ); ?>"></span>
			<?php if ( $ser ) : ?><span class="small muted"><a href="<?php echo esc_url( get_term_link( $ser ) ); ?>" style="color:var(--muted)"><?php echo esc_html( $ser->name ); ?></a></span><?php endif; ?>
			<span class="badge <?php echo $pro ? 'b-pro' : 'b-free'; ?>"><?php echo $pro ? 'Pro' : 'Free'; ?></span>
			<span class="small muted mono">· <?php echo esc_html( hod_duration( $id ) ); ?> · обновлено <?php echo esc_html( get_the_modified_date( 'd.m.Y' ) ); ?></span>
			<button class="savebtn<?php echo $is_saved ? ' on' : ''; ?>" data-hod-save="<?php echo esc_attr( $id ); ?>" aria-pressed="<?php echo $is_saved ? 'true' : 'false'; ?>" title="Сохранить в личном кабинете"><span class="ico" aria-hidden="true"><?php echo $is_saved ? '&#9733;' : '&#9734;'; ?></span> <?php echo $is_saved ? 'Сохранено' : 'Сохранить'; ?></button>
			<span class="save-msg xs muted" role="status" aria-live="polite"></span>
		</div>

		<h1 style="font-size:33px;max-width:24ch">«<?php echo esc_html( $line ); ?>»</h1>
		<?php if ( $g( 'situation_one_liner' ) ) : ?><p class="lead muted" style="font-size:17px;margin-top:12px"><?php echo esc_html( $g( 'situation_one_liner' ) ); ?></p><?php endif; ?>

		<div style="display:flex;gap:8px;flex-wrap:wrap;margin:16px 0 22px">
			<?php foreach ( array( 'role', 'stage', 'industry' ) as $tx ) :
				$terms = get_the_terms( $id, $tx );
				if ( $terms && ! is_wp_error( $terms ) ) { foreach ( $terms as $t ) { echo '<span class="chip">' . esc_html( $t->name ) . '</span>'; } }
			endforeach; ?>
			<?php if ( $g( 'channel' ) ) : ?><span class="chip"><?php echo esc_html( $g( 'channel' ) ); ?></span><?php endif; ?>
			<?php if ( $g( 'difficulty' ) ) : ?><span class="chip">Сложность: <?php echo esc_html( $g( 'difficulty' ) ); ?></span><?php endif; ?>
		</div>

		<?php get_template_part( 'template-parts/videofacade', null, array( 'id' => $id ) ); ?>

		<h2 style="font-size:20px;margin:28px 0 10px">1 · Ситуация</h2>
		<?php if ( $g( 'context_setup' ) ) : ?><p><?php echo esc_html( $g( 'context_setup' ) ); ?></p><?php endif; ?>
		<?php if ( $g( 'stake' ) ) : ?><div class="callout"><b>Что на кону.</b> <?php echo esc_html( $g( 'stake' ) ); ?></div><?php endif; ?>

		<h2 style="font-size:20px;margin:26px 0 10px">2 · Типичная ошибка</h2>
		<?php if ( $g( 'common_mistake' ) ) : ?><div class="bad-say"><b>Что делают:</b> <?php echo esc_html( $g( 'common_mistake' ) ); ?></div><?php endif; ?>
		<?php $ds = hod_lines( $g( 'dont_say' ) ); if ( $ds ) : ?>
			<div class="xs muted" style="margin:14px 0 8px;text-transform:uppercase;letter-spacing:.08em">Так говорить нельзя</div>
			<ul class="small" style="color:#8E1B1B"><?php foreach ( $ds as $d ) : ?><li>«<?php echo esc_html( $d ); ?>»</li><?php endforeach; ?></ul>
		<?php endif; ?>
		<?php if ( $g( 'insight_why' ) ) : ?><div class="callout" style="margin-top:14px"><b>Почему это проигрывает.</b> <?php echo esc_html( $g( 'insight_why' ) ); ?></div><?php endif; ?>

		<?php if ( $gated ) : ?>
			<?php get_template_part( 'template-parts/pro-card-gate', null, array( 'id' => $id, 'code' => $code ) ); ?>
		<?php else : ?>
		<h2 style="font-size:20px;margin:26px 0 10px">3 · Приём: «<?php echo esc_html( $g( 'framework_name_own' ) ); ?>»</h2>
		<?php if ( $g( 'framework_origin' ) ) : ?><p><?php echo esc_html( $g( 'framework_origin' ) ); ?></p><?php endif; ?>

		<h2 style="font-size:20px;margin:26px 0 10px">4 · Диалог</h2>
		<?php get_template_part( 'template-parts/dialogue', null, array( 'id' => $id ) ); ?>
		<?php $kq = hod_lines( $g( 'key_questions' ) ); if ( $kq ) : ?>
			<div class="xs muted" style="margin:14px 0 6px;text-transform:uppercase;letter-spacing:.08em">Ключевые вопросы</div>
			<ul class="small"><?php foreach ( $kq as $q ) : ?><li><?php echo esc_html( $q ); ?></li><?php endforeach; ?></ul>
		<?php endif; ?>

		<h2 style="font-size:20px;margin:26px 0 10px">5 · Ветки: если ответят иначе</h2>
		<?php get_template_part( 'template-parts/pro-gate', null, array( 'id' => $id ) ); ?>

		<h2 style="font-size:20px;margin:26px 0 10px">6 · Результат и следующий шаг</h2>
		<div class="good-say">
			<?php if ( $g( 'desired_outcome' ) ) : ?><b>Результат:</b> <?php echo esc_html( $g( 'desired_outcome' ) ); ?><br><?php endif; ?>
			<b>Следующий шаг:</b> <?php echo esc_html( $g( 'next_step' ) ); ?>
			<?php if ( $g( 'micro_commitment' ) ) : ?><br><b>Фиксируем:</b> <?php echo esc_html( $g( 'micro_commitment' ) ); ?><?php endif; ?>
		</div>

		<?php $sm = hod_lines( $g( 'success_metrics' ) ); $fs = hod_lines( $g( 'failure_signals' ) ); if ( $sm || $fs ) : ?>
			<h2 style="font-size:20px;margin:26px 0 10px">7 · Как понять, что сработало</h2>
			<?php if ( $sm ) : ?><ul class="small"><?php foreach ( $sm as $m ) : ?><li><?php echo esc_html( $m ); ?></li><?php endforeach; ?></ul><?php endif; ?>
			<?php if ( $fs ) : ?><div class="callout warn small"><b>Признаки, что не сработало:</b> <?php echo esc_html( implode( ' · ', $fs ) ); ?></div><?php endif; ?>
		<?php endif; ?>

		<?php endif; ?>

		<h2 style="font-size:20px;margin:26px 0 10px">Источник и границы применимости</h2>
		<dl class="kv card pad">
			<dt>Приём</dt><dd><?php echo esc_html( $g( 'framework_name_own' ) ); ?></dd>
			<?php $modes = array( 'canonical_term' => 'Канонический термин источника', 'adapted_inspired_by' => 'Адаптация по мотивам (название приёма наше)', 'own_framework' => 'Собственный приём из практики', 'practitioner_interview' => 'Из интервью с практиком', 'regulation' => 'Нормативный источник' );
			$am = $g( 'attribution_mode' ); ?>
			<dt>Режим атрибуции</dt><dd><?php echo esc_html( isset( $modes[ $am ] ) ? $modes[ $am ] : $am ); ?></dd>
			<?php if ( $g( 'source_title' ) ) : ?><dt>Источник идеи</dt><dd><?php echo esc_html( $g( 'source_title' ) ); ?><?php if ( $g( 'source_author' ) ) : ?> - <?php echo esc_html( $g( 'source_author' ) ); ?><?php endif; ?><?php if ( $g( 'source_year' ) ) : ?>, <?php echo esc_html( $g( 'source_year' ) ); ?><?php endif; ?></dd><?php endif; ?>
			<?php if ( $g( 'applicability_limits' ) ) : ?><dt>Не работает, когда</dt><dd><?php echo esc_html( $g( 'applicability_limits' ) ); ?><?php if ( $g( 'counter_examples' ) ) : ?> <?php echo esc_html( $g( 'counter_examples' ) ); ?><?php endif; ?></dd><?php endif; ?>
			<?php if ( $g( 'pm_legal_ref' ) ) : ?><dt>Норма ТК РФ</dt><dd><?php echo esc_html( $g( 'pm_legal_ref' ) ); ?></dd><?php endif; ?>
		</dl>

		<div style="margin-top:16px"><?php get_template_part( 'template-parts/disclaimer', null, array( 'id' => $id ) ); ?></div>

		<div class="hr" style="margin:28px 0"></div>
		<?php $prev = get_previous_post( false, '', false, 'series' ); $next = get_next_post( false, '', false, 'series' ); ?>
		<div style="display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap">
			<?php if ( $prev ) : ?><a class="btn btn-o btn-s" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">← <?php echo esc_html( wp_trim_words( get_the_title( $prev ), 5, '…' ) ); ?></a><?php else : ?><span></span><?php endif; ?>
			<div class="small muted" style="align-self:center;text-align:center">Ситуация <b class="mono"><?php echo esc_html( $code ); ?></b><?php if ( $ser ) : ?> · <?php echo esc_html( $ser->name ); ?><?php endif; ?></div>
			<?php if ( $next ) : ?><a class="btn btn-p btn-s" href="<?php echo esc_url( get_permalink( $next ) ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( $next ), 5, '…' ) ); ?> →</a><?php else : ?><span></span><?php endif; ?>
		</div>

		<?php $rel = hod_related( $id, 3 ); if ( $rel ) : ?>
			<h2 style="font-size:20px;margin:30px 0 14px">Связанные ситуации</h2>
			<div class="grid g3"><?php foreach ( $rel as $rp ) { get_template_part( 'template-parts/card-situation', null, array( 'post' => $rp ) ); } ?></div>
		<?php endif; ?>
	</article>

	<aside><div class="rail">
		<div class="card pad" style="margin-bottom:16px">
			<div class="xs muted" style="text-transform:uppercase;letter-spacing:.09em;margin-bottom:10px">В этой карточке</div>
			<ol class="small" style="padding-left:18px;margin:0">
				<li><a href="#">Ситуация</a></li><li><a href="#">Типичная ошибка</a></li><li><a href="#">Приём</a></li>
				<li><a href="#">Диалог</a></li><li><a href="#">Ветки <?php if ( ! hod_is_pro() ) : ?><span class="badge b-pro" style="padding:1px 6px">Pro</span><?php endif; ?></a></li>
				<li><a href="#">Результат и шаг</a></li><li><a href="#">Метрики</a></li><li><a href="#">Источник и границы</a></li>
			</ol>
		</div>
		<?php if ( hod_is_pro() ) : ?>
		<div class="card pad" style="margin-bottom:16px">
			<b style="font-size:15px">Экспорт карточки</b>
			<p class="small muted" style="margin:8px 0 10px">PDF через диалог печати браузера, Markdown или TXT для Notion. Pro-поля включаются полностью.</p>
			<div style="display:flex;gap:8px;flex-wrap:wrap">
				<a class='btn btn-a btn-s' target='_blank' rel='noopener' href='<?php echo esc_url( add_query_arg( 'hod_export', 'pdf', get_permalink( $id ) ) ); ?>'>PDF</a>
				<a class='btn btn-o btn-s' href='<?php echo esc_url( add_query_arg( 'hod_export', 'md', get_permalink( $id ) ) ); ?>'>Markdown</a>
				<a class='btn btn-o btn-s' href='<?php echo esc_url( add_query_arg( 'hod_export', 'txt', get_permalink( $id ) ) ); ?>'>TXT</a>
			</div>
			<p class='xs muted' style='margin-top:10px'><a href='<?php echo esc_url( function_exists( 'hod_account_url' ) ? hod_account_url() : home_url( '/account/' ) ); ?>'>Личный кабинет</a> · сохранённых: <?php echo count( $saved_ids ); ?></p>
		</div>
		<?php else : ?>
		<div class="card pad" style="margin-bottom:16px;border-color:#FFD8C7;background:var(--accent-t)">
			<b style="font-size:15px">Pro: ветки, шаблоны, экспорт</b>
			<p class="small" style="margin:8px 0 12px">Ветки диалога, скрипты писем, чек-листы, PDF/Notion-экспорт, поиск без ограничений и категория «Управление персоналом».</p>
			<a class="btn btn-a btn-s" style="width:100%" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">390 ₽/мес · первый месяц 99 ₽</a>
		</div>
		<?php endif; ?>
		<div class="card pad">
			<div class="xs muted" style="text-transform:uppercase;letter-spacing:.09em;margin-bottom:10px">Это ваша ситуация?</div>
			<p class="small muted" style="margin-bottom:10px">Опишите, что сказал собеседник, - разберём в ближайшем выпуске.</p>
			<a class="btn btn-o btn-s" style="width:100%" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a>
		</div>
		<?php if ( $g( 'video_mp4' ) && hod_is_pro() ) : ?>
			<div class="card pad" style="margin-top:16px"><a class="btn btn-o btn-s" style="width:100%" href="<?php echo esc_url( $g( 'video_mp4' ) ); ?>" download>Скачать видео (MP4)</a></div>
		<?php endif; ?>
	</div></aside>
</div>
<div class="hod-sticky-cta">
	<span class="small"><b class="mono"><?php echo esc_html( $code ); ?></b> · <?php echo esc_html( wp_trim_words( $line, 6, '…' ) ); ?></span>
	<a class="btn btn-a btn-s" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Ветки и шаблоны в Pro</a>
</div>
<?php endwhile; get_footer(); ?>
