<?php defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap article" style="padding-top:28px;padding-bottom:48px">
	<?php hod_breadcrumbs(); while ( have_posts() ) : the_post(); ?>
	<h1><?php the_title(); ?></h1>
	<p class="small muted"><?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?></p>
	<div class="entry-content" style="margin-top:20px"><?php the_content(); ?></div>
	<?php endwhile; ?>
	<div style="margin-top:30px"><?php get_template_part( 'template-parts/lead-magnet' ); ?></div>
</div>
<?php get_footer(); ?>
