<?php defined( 'ABSPATH' ) || exit; get_header();
/** Каталог с фильтрами. Работает и как archive CPT, и как страница /catalog/ (назначить этот шаблон). */
$args_tax = array();
foreach ( array( 'origin', 'role', 'stage', 'series', 'domain' ) as $tx ) {
	if ( ! empty( $_GET[ $tx ] ) ) { $args_tax[] = array( 'taxonomy' => $tx, 'field' => 'slug', 'terms' => array_map( 'sanitize_title', (array) $_GET[ $tx ] ) ); }
}
$paged = max( 1, get_query_var( 'paged' ), isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1 );
$q = new WP_Query( array(
	'post_type' => 'situation', 'posts_per_page' => 12, 'paged' => $paged,
	'tax_query' => $args_tax ? $args_tax : '',
	'orderby' => isset( $_GET['orderby'] ) && 'code' === $_GET['orderby'] ? 'meta_value' : 'date',
	'meta_key' => isset( $_GET['orderby'] ) && 'code' === $_GET['orderby'] ? 'code' : '',
) );
function hod_filter_url( $key, $val ) {
	$a = $_GET; $a[ $key ] = $val; $a['paged'] = false;
	return esc_url( add_query_arg( array_filter( $a ), home_url( '/catalog/' ) ) );
}
?>
<div class="wrap" style="padding-top:28px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<div class="blk-h"><div><h1 style="font-size:30px">Каталог ситуаций</h1><p><?php echo (int) $q->found_posts; ?> ситуаций · фильтры сохраняются в адресе страницы, ссылку можно отправить коллеге</p></div></div>
	<div class="two">
		<aside class="rail card pad">
			<form method="get" action="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">
			<?php foreach ( array( 'origin' => 'Библиотека', 'role' => 'Роль', 'stage' => 'Этап воронки', 'series' => 'Серия', 'domain' => 'Домен' ) as $tx => $label ) :
				$terms = get_terms( array( 'taxonomy' => $tx, 'hide_empty' => true ) );
				if ( ! $terms || is_wp_error( $terms ) ) { continue; }
				$sel = isset( $_GET[ $tx ] ) ? (array) $_GET[ $tx ] : array();
				?>
				<h4><?php echo esc_html( $label ); ?></h4>
				<?php foreach ( $terms as $t ) : ?>
					<label><input type="checkbox" name="<?php echo esc_attr( $tx ); ?>[]" value="<?php echo esc_attr( $t->slug ); ?>" <?php checked( in_array( $t->slug, $sel, true ) ); ?>> <?php echo esc_html( $t->name ); ?> <span class="muted">(<?php echo (int) $t->count; ?>)</span></label>
				<?php endforeach; ?>
			<?php endforeach; ?>
			<div style="margin-top:18px;display:flex;gap:8px">
				<button class="btn btn-p btn-s" style="flex:1">Показать</button>
				<a class="btn btn-g btn-s" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Сброс</a>
			</div>
			</form>
		</aside>
		<div>
			<?php if ( $q->have_posts() ) : ?>
				<div class="grid g3"><?php while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'template-parts/card-situation' ); endwhile; ?></div>
				<div class="pagination"><?php
					echo paginate_links( array(
						'total' => $q->max_num_pages, 'current' => $paged, 'prev_text' => '←', 'next_text' => '→',
						'add_args' => array_filter( $_GET ), 'base' => add_query_arg( 'paged', '%#%' ),
					) );
				?></div>
				<?php wp_reset_postdata(); ?>
			<?php else : ?>
				<div class="card pad">
					<h3>Ничего не найдено</h3>
					<p class="small muted">Такой ситуации в библиотеке пока нет. Это не тупик: опишите, что сказал собеседник, - разберём в одном из ближайших выпусков.</p>
					<p><a class="btn btn-p btn-s" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a>
					<a class="btn btn-o btn-s" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Сбросить фильтры</a></p>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>
