<?php defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap article" style="padding-top:28px;padding-bottom:48px;max-width:840px">
	<?php hod_breadcrumbs(); while ( have_posts() ) : the_post(); ?>
	<h1><?php the_title(); ?></h1>
	<div class="entry-content" style="margin-top:18px"><?php the_content(); ?></div>
	<?php endwhile; ?>
</div>
<?php get_footer(); ?>
