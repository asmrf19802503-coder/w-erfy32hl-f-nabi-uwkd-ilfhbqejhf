<?php defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap" style="padding-top:28px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<h1 style="font-size:30px"><?php is_home() ? bloginfo( 'name' ) : the_archive_title(); ?></h1>
	<div class="grid g2" style="margin-top:22px">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article class="card pad"><h2 style="font-size:19px"><a href="<?php the_permalink(); ?>" style="color:inherit"><?php the_title(); ?></a></h2>
		<p class="small muted" style="margin:8px 0 12px"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 28 ) ); ?></p>
		<a class="btn btn-o btn-s" href="<?php the_permalink(); ?>">Читать</a></article>
	<?php endwhile; else : ?><p class="muted">Записей пока нет.</p><?php endif; ?>
	</div>
	<div class="pagination"><?php echo paginate_links(); ?></div>
</div>
<?php get_footer(); ?>
