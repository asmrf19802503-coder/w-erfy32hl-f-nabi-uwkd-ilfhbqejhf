<?php defined( 'ABSPATH' ) || exit; get_header();
$t = get_queried_object(); $col = get_term_meta( $t->term_id, 'hod_color', true ); if ( ! $col ) { $col = '#1B4DFF'; }
$q = new WP_Query( array( 'post_type' => 'situation', 'posts_per_page' => 60, 'tax_query' => array( array( 'taxonomy' => 'series', 'field' => 'term_id', 'terms' => $t->term_id ) ), 'orderby' => 'meta_value', 'meta_key' => 'code', 'order' => 'ASC', 'no_found_rows' => true ) );
?>
<div class="wrap" style="padding-top:28px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<div style="display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap">
		<div style="flex:1;min-width:280px">
			<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px"><span class="seriesdot" style="width:14px;height:14px;border-radius:4px;background:<?php echo esc_attr( $col ); ?>"></span><span class="mono small muted">Серия <?php echo esc_html( strtoupper( $t->slug ) ); ?> · <?php echo (int) $t->count; ?> ситуаций</span></div>
			<h1 style="font-size:32px"><?php echo esc_html( $t->name ); ?></h1>
			<?php if ( $t->description ) : ?><p class="muted" style="max-width:64ch;margin-top:12px"><?php echo wp_kses_post( $t->description ); ?></p><?php endif; ?>
			<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px">
				<?php $rt = get_terms( array( 'taxonomy' => 'role', 'hide_empty' => false ) ); foreach ( $rt as $r ) { echo '<span class="chip">' . esc_html( $r->name ) . '</span>'; break; } ?>
			</div>
		</div>
		<div class="card pad" style="width:270px">
			<div class="xs muted" style="text-transform:uppercase;letter-spacing:.09em;margin-bottom:8px">Прогресс серии</div>
			<div style="font-size:30px;font-weight:800;letter-spacing:-.03em"><?php echo (int) $t->count; ?></div>
			<div class="small muted" style="margin:6px 0 14px">ситуаций опубликовано</div>
			<div style="height:6px;background:var(--mist2);border-radius:99px;overflow:hidden"><div style="width:100%;height:100%;background:<?php echo esc_attr( $col ); ?>"></div></div>
			<div class="hr" style="margin:16px 0"></div>
			<a class="btn btn-p btn-s" style="width:100%" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Скачать серию (PDF)</a>
			<a class="btn btn-o btn-s" style="width:100%;margin-top:8px" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Предложить ситуацию</a>
		</div>
	</div>
	<div class="hr" style="margin:30px 0 22px"></div>
	<h2 style="font-size:20px;margin-bottom:14px">Порядок просмотра</h2>
	<div class="card" style="overflow:hidden"><table class="tbl" style="border:0;border-radius:0">
		<thead><tr><th style="width:78px">Код</th><th>Ситуация</th><th style="width:200px">Реплика</th><th style="width:180px">Приём</th><th style="width:66px">Видео</th><th style="width:70px">Доступ</th></tr></thead>
		<tbody>
		<?php while ( $q->have_posts() ) : $q->the_post(); $id = get_the_ID(); ?>
			<tr>
				<td class="mono"><?php echo esc_html( hod_meta( $id, 'code' ) ); ?></td>
				<td><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></td>
				<td class="small">«<?php echo esc_html( wp_trim_words( hod_meta( $id, 'counterpart_line' ), 6, '…' ) ); ?>»</td>
				<td class="small"><?php echo esc_html( hod_meta( $id, 'framework_name_own' ) ); ?></td>
				<td class="mono"><?php echo esc_html( hod_duration( $id ) ); ?></td>
				<td><span class="badge <?php echo 'pro' === hod_meta( $id, 'access_level', 'free' ) ? 'b-pro' : 'b-free'; ?>"><?php echo 'pro' === hod_meta( $id, 'access_level', 'free' ) ? 'Pro' : 'Free'; ?></span></td>
			</tr>
		<?php endwhile; wp_reset_postdata(); ?>
		</tbody>
	</table></div>
	<div class="grid g2" style="margin-top:26px">
		<div class="callout"><b>Что в Pro-версии серии.</b> Ветки диалога, шаблоны писем и расчётов, чек-листы, экспорт в PDF и Notion.</div>
		<div class="callout warn"><b>Следующие серии.</b> Квалификация, демо, закрытие сделки, управление персоналом. <a href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Подписаться на Pro →</a></div>
	</div>
</div>
<?php get_footer(); ?>
