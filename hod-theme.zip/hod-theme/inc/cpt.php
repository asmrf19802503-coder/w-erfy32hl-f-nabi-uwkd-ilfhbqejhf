<?php
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_type( 'situation', array(
		'labels' => array(
			'name'          => 'Ситуации',
			'singular_name' => 'Ситуация',
			'add_new_item'  => 'Добавить ситуацию',
			'edit_item'     => 'Редактировать ситуацию',
			'menu_name'     => 'Библиотека',
		),
		'public'       => true,
		'show_in_rest' => true,
		'has_archive'  => 'catalog',
		'rewrite'      => array( 'slug' => 's', 'with_front' => false ),
		'menu_icon'    => 'dashicons-format-quote',
		'menu_position'=> 5,
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
	) );

	register_post_type( 'source', array(
		'labels' => array( 'name' => 'Источники', 'singular_name' => 'Источник', 'menu_name' => 'Источники' ),
		'public'       => true,
		'show_in_rest' => true,
		'rewrite'      => array( 'slug' => 'source' ),
		'menu_icon'    => 'dashicons-book-alt',
		'supports'     => array( 'title', 'editor', 'thumbnail' ),
	) );

	$common = array( 'public' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true );

	register_taxonomy( 'series', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Серии', 'singular_name' => 'Серия' ),
		'rewrite' => array( 'slug' => 'series' ),
	) );
	register_taxonomy( 'objection', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Возражения', 'singular_name' => 'Возражение' ),
		'rewrite' => array( 'slug' => 'objections' ),
	) );
	register_taxonomy( 'role', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Роли', 'singular_name' => 'Роль' ),
		'rewrite' => array( 'slug' => 'roles' ),
	) );
	register_taxonomy( 'stage', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Этапы воронки', 'singular_name' => 'Этап' ),
		'rewrite' => array( 'slug' => 'stages' ),
	) );
	register_taxonomy( 'domain', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Домены', 'singular_name' => 'Домен' ),
		'rewrite' => array( 'slug' => 'domain' ),
	) );
	register_taxonomy( 'industry', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Отрасли и рынок', 'singular_name' => 'Отрасль' ),
		'rewrite' => array( 'slug' => 'industries' ),
	) );

	/* Слой библиотеки: мировая практика / Россия и СНГ. Первый фильтр каталога. */
	register_taxonomy( 'origin', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Библиотека (происхождение)', 'singular_name' => 'Слой' ),
		'rewrite' => array( 'slug' => 'origin' ),
	) );

	register_taxonomy( 'source_tax', array( 'situation' ), $common + array(
		'labels' => array( 'name' => 'Источники (таксономия)', 'singular_name' => 'Источник' ),
		'rewrite' => array( 'slug' => 'sources' ),
	) );
} );

/** Цвет серии хранится в мета термина. */
add_action( 'series_add_form_fields', function () {
	echo '<div class="form-field"><label for="hod_color">Цвет серии (hex)</label><input name="hod_color" id="hod_color" type="text" value="#2563EB" /><p class="description">Используется в полосе карточки, чипе и плашке ролика.</p></div>';
} );
add_action( 'series_edit_form_fields', function ( $term ) {
	$v = get_term_meta( $term->term_id, 'hod_color', true );
	echo '<tr class="form-field"><th scope="row"><label for="hod_color">Цвет серии (hex)</label></th><td><input name="hod_color" id="hod_color" type="text" value="' . esc_attr( $v ? $v : '#2563EB' ) . '" /></td></tr>';
} );
add_action( 'created_series', 'hod_save_term_color', 10, 2 );
add_action( 'edited_series', 'hod_save_term_color', 10, 2 );
function hod_save_term_color( $term_id, $tt_id ) {
	if ( isset( $_POST['hod_color'] ) ) {
		update_term_meta( $term_id, 'hod_color', sanitize_hex_color( wp_unslash( $_POST['hod_color'] ) ) );
	}
}

/** Колонки в админке. */
add_filter( 'manage_situation_posts_columns', function ( $c ) {
	$n = array();
	foreach ( $c as $k => $v ) {
		$n[ $k ] = $v;
		if ( 'title' === $k ) {
			$n['hod_code']  = 'Код';
			$n['hod_series']= 'Серия';
			$n['hod_access']= 'Доступ';
			$n['hod_score'] = 'Score';
			$n['hod_wf']    = 'Статус';
		}
	}
	return $n;
} );
add_action( 'manage_situation_posts_custom_column', function ( $col, $id ) {
	switch ( $col ) {
		case 'hod_code':   echo '<code>' . esc_html( get_post_meta( $id, 'code', true ) ) . '</code>'; break;
		case 'hod_series': $t = get_the_terms( $id, 'series' ); echo $t && ! is_wp_error( $t ) ? esc_html( $t[0]->name ) : '-'; break;
		case 'hod_access': echo 'pro' === get_post_meta( $id, 'access_level', true ) ? '<span style="color:#B33C0C;font-weight:700">PRO</span>' : 'free'; break;
		case 'hod_score':  echo esc_html( get_post_meta( $id, 'quality_score', true ) ); break;
		case 'hod_wf':     echo esc_html( get_post_meta( $id, 'status_wf', true ) ); break;
	}
}, 10, 2 );
