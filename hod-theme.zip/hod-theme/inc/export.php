<?php
/**
 * Экспорт карточки и защищённая отдача Pro-файлов.
 * Работает только для пользователей с доступом Pro (проверка hod_is_pro() на сервере).
 *
 * URL:
 *   /situation/[slug]/?hod_export=md   - скачать карточку в Markdown
 *   /situation/[slug]/?hod_export=txt  - скачать в TXT (вставка в Notion)
 *   /situation/[slug]/?hod_file=0      - скачать Pro-файл по индексу из поля pro_files
 */
defined( 'ABSPATH' ) || exit;

/** Собрать содержимое карточки в виде массива "заголовок => текст". */
function hod_card_export_data( $id ) {
	$g = function ( $k ) use ( $id ) {
		return function_exists( 'get_field' ) ? (string) get_field( $k, $id ) : (string) hod_meta( $id, $k );
	};
	$out = array();
	$out['Код']            = $g( 'code' );
	$out['Ситуация']       = $g( 'situation_one_liner' );
	$out['Реплика']        = $g( 'counterpart_line' );
	$out['Контекст']       = $g( 'context_setup' );
	$out['Что на кону']    = $g( 'stake' );
	$out['Типичная ошибка']= $g( 'common_mistake' );
	$out['Так говорить нельзя'] = implode( "\n", hod_lines( $g( 'dont_say' ) ) );
	$out['Почему проигрывает']  = $g( 'insight_why' );
	$out['Приём']          = $g( 'framework_name_own' );
	$out['Суть приёма']    = $g( 'framework_origin' );
	$out['Диалог']         = $g( 'dialogue_turns' );
	$out['Ключевые вопросы'] = implode( "\n", hod_lines( $g( 'key_questions' ) ) );

	$out['Ветки: если ответят иначе'] = '';
	foreach ( hod_branches( $g( 'branches' ) ) as $b ) {
		$out['Ветки: если ответят иначе'] .= '- ' . $b['if'] . ( $b['then'] ? ' - ' . $b['then'] : '' ) . "\n";
	}
	$out['Тренажёр: развилки'] = '';
	foreach ( hod_drills( $g( 'pro_drill' ) ) as $d ) {
		$out['Тренажёр: развилки'] .= '- ' . $d['case'] . "\n";
		if ( $d['right'] ) { $out['Тренажёр: развилки'] .= '  Верно: ' . $d['right'] . "\n"; }
		if ( $d['wrong'] ) { $out['Тренажёр: развилки'] .= '  Неверно: ' . $d['wrong'] . "\n"; }
		if ( $d['why'] )   { $out['Тренажёр: развилки'] .= '  Почему: ' . $d['why'] . "\n"; }
	}
	$out['Готовые формулировки'] = implode( "\n", hod_lines( $g( 'pro_templates' ) ) );
	$out['Чек-лист подготовки']  = implode( "\n", array_map( function ( $x ) { return '[ ] ' . $x; }, hod_lines( $g( 'pro_checklist' ) ) ) );
	$out['Пак инструментов']     = $g( 'pro_pack' );
	$out['Результат']            = $g( 'desired_outcome' );
	$out['Следующий шаг']        = $g( 'next_step' );
	$out['Фиксируем']            = $g( 'micro_commitment' );
	$out['Метрики успеха']       = implode( "\n", hod_lines( $g( 'success_metrics' ) ) );
	$out['Признаки, что не сработало'] = implode( "\n", hod_lines( $g( 'failure_signals' ) ) );
	$out['Источник идеи']        = trim( $g( 'source_title' ) . ' ' . $g( 'source_author' ) . ' ' . $g( 'source_year' ) );
	$out['Режим атрибуции']      = $g( 'attribution_mode' );
	$out['Не работает, когда']   = $g( 'applicability_limits' ) . ' ' . $g( 'counter_examples' );
	if ( $g( 'pm_legal_ref' ) ) { $out['Норма ТК РФ'] = $g( 'pm_legal_ref' ); }
	$out['Дисклеймер']           = $g( 'disclaimer_text' );
	return array_filter( $out, function ( $v ) { return '' !== trim( (string) $v ); } );
}

add_action( 'template_redirect', function () {
	$export = isset( $_GET['hod_export'] ) ? sanitize_key( wp_unslash( $_GET['hod_export'] ) ) : '';
	$file   = isset( $_GET['hod_file'] ) && '' !== $_GET['hod_file'] ? (int) $_GET['hod_file'] : -1;
	$print  = isset( $_GET['hod_print'] );

	if ( '' === $export && $file < 0 && ! $print ) { return; }
	if ( ! is_singular( 'situation' ) ) { return; }

	$id = get_queried_object_id();
	if ( ! hod_is_pro() ) {
		status_header( 403 );
		wp_die( 'Экспорт и файлы Pro доступны по подписке. <a href="' . esc_url( home_url( '/pro/' ) ) . '">Открыть Pro</a>', 'Только Pro', array( 'response' => 403 ) );
	}

	// --- PDF: печатный вид (браузер сохраняет в PDF без сторонних библиотек) --
	if ( 'pdf' === $export ) {
		wp_redirect( add_query_arg( 'hod_print', 1, get_permalink( $id ) ) );
		exit;
	}
	if ( $print ) {
		hod_render_print( $id );
		exit;
	}

	// --- отдача Pro-файла ---------------------------------------------------
	if ( $file >= 0 ) {
		$files = array_values( array_filter( array_map( 'trim', explode( ',', (string) hod_meta( $id, 'pro_files' ) ) ) ) );
		if ( ! isset( $files[ $file ] ) ) { wp_die( 'Файл не найден', '404', array( 'response' => 404 ) ); }
		$url  = $files[ $file ];
		$path = str_replace( content_url(), WP_CONTENT_DIR, $url );
		if ( ! $path || ! is_readable( $path ) ) {
			wp_redirect( $url ); // внешний файл: отдаём ссылку после проверки доступа
			exit;
		}
		nocache_headers();
		header( 'Content-Type: ' . ( function_exists( 'wp_check_filetype' ) ? ( wp_check_filetype( $path )['type'] ?: 'application/octet-stream' ) : 'application/octet-stream' ) );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( basename( $path ) ) . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		readfile( $path );
		exit;
	}

	// --- экспорт карточки ----------------------------------------------------
	$data  = hod_card_export_data( $id );
	$title = get_the_title( $id );
	$code  = hod_meta( $id, 'code', '' );
	$stamp = gmdate( 'd.m.Y' );

	if ( 'txt' === $export ) {
		$body = $code . ' · ' . $title . "\n" . str_repeat( '=', 60 ) . "\n\n";
		foreach ( $data as $k => $v ) { $body .= strtoupper( $k ) . "\n" . $v . "\n\n"; }
		$body .= "\nВыгружено с " . home_url() . ' ' . $stamp . '. Pro-доступ: ' . ( hod_is_team() ? 'Team' : 'Pro' ) . '.\n';
		$type = 'text/plain; charset=utf-8';
		$ext  = 'txt';
	} else {
		$body = '# ' . $title . "\n\n**Код:** `" . $code . "` · **Выгружено:** " . $stamp . "\n\n";
		foreach ( $data as $k => $v ) { $body .= '## ' . $k . "\n\n" . $v . "\n\n"; }
		$body .= '---\n\nВыгружено с ' . home_url() . '. Материалы Pro предназначены для личного использования и обучения своей команды.\n';
		$type = 'text/markdown; charset=utf-8';
		$ext  = 'md';
	}

	nocache_headers();
	header( 'Content-Type: ' . $type );
	header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $code . '-' . $title ) . '.' . $ext . '"' );
	echo $body; // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
} );


/**
 * Печатный вид карточки: самодостаточный HTML без внешних ресурсов.
 * Пользователь сохраняет в PDF через диалог печати браузера (Ctrl/Cmd + P -> «Сохранить как PDF»).
 * Если позже понадобится серверный PDF - подключаем dompdf/tcptf в этом же месте, разметка готова.
 */
function hod_render_print( $id ) {
	$data  = hod_card_export_data( $id );
	$title = get_the_title( $id );
	$code  = hod_meta( $id, 'code', '' );
	$line  = hod_meta( $id, 'counterpart_line', $title );
	$ser   = hod_series( $id );
	unset( $data['Код'] );
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $code . ' · ' . $title ); ?></title>
<style>
:root{--ink:#10131A;--muted:#5A6478;--line:#E3E7EF;--brand:#1B4DFF;--mist:#F6F7F9}
*{box-sizing:border-box}
body{margin:0;background:#fff;color:var(--ink);font:15px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
.sheet{max-width:760px;margin:0 auto;padding:26px 22px 40px}
.bar{position:sticky;top:0;background:#fff;border-bottom:1px solid var(--line);padding:12px 0;margin-bottom:18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.btn{display:inline-block;border:1px solid var(--brand);background:var(--brand);color:#fff;border-radius:10px;padding:9px 14px;font-size:14px;font-weight:600;text-decoration:none;cursor:pointer}
.btn.o{background:#fff;color:var(--brand)}
h1{font-size:24px;line-height:1.25;margin:0 0 6px}
.meta{color:var(--muted);font-size:13px;margin-bottom:20px}
h2{font-size:15px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin:24px 0 8px;border-bottom:1px solid var(--line);padding-bottom:5px}
p,li{font-size:14.5px}
ul,ol{padding-left:20px;margin:8px 0}
li{margin-bottom:5px}
.box{border:1px solid var(--line);border-radius:10px;padding:12px 14px;background:var(--mist);margin:8px 0}
.foot{margin-top:28px;padding-top:14px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
@media print{.bar{display:none}.sheet{padding:0;max-width:none}h2{break-after:avoid}li,.box{break-inside:avoid}}
</style>
</head>
<body>
<div class="sheet">
	<div class="bar">
		<button class="btn" onclick="window.print()">Сохранить в PDF / печать</button>
		<a class="btn o" href="<?php echo esc_url( get_permalink( $id ) ); ?>">Вернуться к карточке</a>
		<span class="mono" style="color:var(--muted);font-size:12px">Pro-доступ: <?php echo esc_html( hod_is_team() ? 'Team' : 'Pro' ); ?> · <?php echo esc_html( date_i18n( 'd.m.Y' ) ); ?></span>
	</div>
	<span class="mono" style="font-size:12px;color:var(--brand);font-weight:700"><?php echo esc_html( $code ); ?><?php if ( $ser ) : ?> · <?php echo esc_html( $ser->name ); ?><?php endif; ?></span>
	<h1>«<?php echo esc_html( $line ); ?>»</h1>
	<div class="meta">ХОД · Библиотека рабочих ситуаций · <?php echo esc_url( get_permalink( $id ) ); ?></div>
	<?php foreach ( $data as $k => $v ) : ?>
		<h2><?php echo esc_html( $k ); ?></h2>
		<div class="box"><?php echo nl2br( esc_html( (string) $v ) ); ?></div>
	<?php endforeach; ?>
	<div class="foot">Материалы Pro предназначены для личного использования и обучения собственной команды. Публикация и перепродажа не допускаются. <?php echo esc_html( home_url( '/' ) ); ?></div>
</div>
<script>
window.addEventListener('load',function(){
  var key='hodPrinted<?php echo (int) $id; ?>';
  try{ if(!sessionStorage.getItem(key)){ sessionStorage.setItem(key,'1'); setTimeout(function(){ window.print(); },350); } }catch(e){}
});
</script>
</body>
</html>
	<?php
}
