<?php
defined( 'ABSPATH' ) || exit;

/**
 * Доступ Pro. Работает в трёх режимах:
 * 1) Paid Memberships Plus - если установлен;
 * 2) WooCommerce Memberships / Subscriptions - если установлен;
 * 3) встроенный ручной доступ: мета пользователя hod_access_until (дата).
 */
function hod_is_pro() {
	if ( ! is_user_logged_in() ) { return false; }
	$uid = get_current_user_id();
	if ( function_exists( 'pmpro_hasMembershipLevel' ) && pmpro_hasMembershipLevel( array( 'pro', 'team' ) ) ) { return true; }
	if ( function_exists( 'wc_memberships_is_post_content_restricted' ) ) {
		$p = get_posts( array( 'numberposts' => 1, 'post_type' => 'any', 'post_status' => 'publish', 'fields' => 'ids', 'meta_key' => 'access_level', 'meta_value' => 'pro' ) );
		if ( $p && ! wc_memberships_is_post_content_restricted( $p[0], $uid ) ) { return true; }
	}
	if ( function_exists( 'hod_is_paused' ) && hod_is_paused( $uid ) ) { return false; }
	$until = get_user_meta( $uid, 'hod_access_until', true );
	return $until && strtotime( $until ) > current_time( 'timestamp' );
}

function hod_is_team() {
	if ( function_exists( 'pmpro_hasMembershipLevel' ) && pmpro_hasMembershipLevel( 'team' ) ) { return true; }
	return 'team' === get_user_meta( get_current_user_id(), 'hod_access_level', true );
}

/** Продлить доступ вручную (после оплаты через Robokassa/YooKassa или доната). */
function hod_grant_access( $user_id, $days = 30, $level = 'pro' ) {
	$until = date( 'Y-m-d H:i:s', strtotime( "+{$days} days" ) );
	update_user_meta( $user_id, 'hod_access_until', $until );
	update_user_meta( $user_id, 'hod_access_level', $level );
	return $until;
}

/** Pro-контент отдаётся только с проверкой на сервере. */
function hod_pro_content( $post_id, $content ) {
	if ( hod_is_pro() ) { return $content; }
	return '';
}

/** Админка: выдача доступа и список Pro-пользователей. */
add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=situation', 'Доступ Pro', 'Доступ Pro', 'manage_options', 'hod-access', function () {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Нет прав' ); }
		$msg = '';
		if ( isset( $_POST['hod_grant'] ) && check_admin_referer( 'hod_grant' ) ) {
			$login = sanitize_text_field( wp_unslash( $_POST['login'] ) );
			$days  = max( 1, (int) $_POST['days'] );
			$u = get_user_by( 'login', $login ) ? get_user_by( 'login', $login ) : get_user_by( 'email', $login );
			if ( $u ) {
				$until = hod_grant_access( $u->ID, $days, isset( $_POST['level'] ) ? sanitize_key( $_POST['level'] ) : 'pro' );
				$msg = 'Доступ для ' . esc_html( $u->user_login ) . ' продлён до ' . esc_html( $until );
			} else {
				$msg = 'Пользователь не найден: ' . esc_html( $login );
			}
		}
		echo '<div class="wrap"><h1>Доступ Pro</h1>';
		if ( $msg ) { echo '<div class="notice notice-success"><p>' . wp_kses_post( $msg ) . '</p></div>'; }
		echo '<form method="post">' . wp_nonce_field( 'hod_grant', '_wpnonce', true, false );
		echo '<table class="form-table"><tr><th>Email или логин</th><td><input name="login" type="text" class="regular-text" required></td></tr>';
		echo '<tr><th>Дней</th><td><input name="days" type="number" value="30" min="1" style="width:90px"> <select name="level"><option value="pro">pro</option><option value="team">team</option></select></td></tr></table>';
		echo '<p><button class="button button-primary" name="hod_grant" value="1">Выдать доступ</button></p></form>';
		$users = get_users( array( 'meta_key' => 'hod_access_until', 'orderby' => 'meta_value', 'order' => 'DESC', 'number' => 50 ) );
		echo '<h2>Текущие доступы</h2><table class="widefat striped"><thead><tr><th>Пользователь</th><th>Email</th><th>Уровень</th><th>Действует до</th></tr></thead><tbody>';
		foreach ( $users as $u ) {
			echo '<tr><td>' . esc_html( $u->user_login ) . '</td><td>' . esc_html( $u->user_email ) . '</td><td>' . esc_html( get_user_meta( $u->ID, 'hod_access_level', true ) ) . '</td><td>' . esc_html( get_user_meta( $u->ID, 'hod_access_until', true ) ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

/** Короткий код для Pro-блоков в любой записи: [hod_pro]текст[/hod_pro] */
add_shortcode( 'hod_pro', function ( $atts, $content = '' ) {
	if ( hod_is_pro() ) { return do_shortcode( $content ); }
	return '<div class="card pad" style="background:var(--accent-t);border-color:#FFD8C7"><span class="badge b-pro">Только в Pro</span><p class="small" style="margin:10px 0 12px">Ветвления диалога, шаблоны и экспорт - в подписке Pro.</p><a class="btn btn-a btn-s" href="' . esc_url( home_url( '/pro/' ) ) . '">Открыть доступ</a></div>';
} );

/** Шорткод кнопки покупки: [hod_buy level="pro" price="390" text="Купить"] */
add_shortcode( 'hod_buy', function ( $atts ) {
	$a = shortcode_atts( array( 'level' => 'pro', 'price' => '', 'text' => 'Оформить доступ', 'days' => 30 ), $atts );
	$url = get_option( 'hod_pay_url_' . $a['level'], '' );
	if ( ! $url ) { $url = home_url( '/pro/#pay' ); }
	return '<a class="btn btn-a" href="' . esc_url( $url ) . '" rel="nofollow" data-level="' . esc_attr( $a['level'] ) . '">' . esc_html( $a['text'] ) . ( $a['price'] ? ' - ' . esc_html( $a['price'] ) . ' ₽' : '' ) . '</a>';
} );

/** Настройки темы в Customizer: hero, платёжные ссылки, соцсети. */
add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'hod_section', array( 'title' => 'ХОД: библиотека', 'priority' => 30 ) );
	$fields = array(
		'hod_hero_title' => array( 'Заголовок первого экрана', 'Что сказать, когда клиент говорит «дорого»' ),
		'hod_hero_lead'  => array( 'Подзаголовок', 'Библиотека рабочих ситуаций в продажах, маркетинге и управлении.' ),
		'hod_pay_url_pro'  => array( 'Ссылка оплаты Pro', '' ),
		'hod_pay_url_team' => array( 'Ссылка оплаты Team', '' ),
		'hod_tg'  => array( 'Telegram-канал', '' ),
		'hod_yt'  => array( 'YouTube-канал', '' ),
		'hod_vk'  => array( 'VK-видео', '' ),
	);
	foreach ( $fields as $id => $cfg ) {
		$wp_customize->add_setting( $id, array( 'default' => $cfg[1], 'sanitize_callback' => 'wp_filter_nohtml_kses' ) );
		$wp_customize->add_control( $id, array( 'label' => $cfg[0], 'section' => 'hod_section', 'type' => 'text' ) );
	}
} );
