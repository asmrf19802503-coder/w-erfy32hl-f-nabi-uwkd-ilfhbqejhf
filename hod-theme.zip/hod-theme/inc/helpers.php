<?php
defined( 'ABSPATH' ) || exit;

/** Разбить textarea на строки. Разделители: перенос строки или « | ». */
function hod_lines( $v ) {
	if ( is_array( $v ) ) { return array_values( array_filter( array_map( 'trim', $v ) ) ); }
	$v = (string) $v;
	if ( '' === trim( $v ) ) { return array(); }
	$parts = preg_split( '/\r\n|\r|\n/', $v );
	$out = array();
	foreach ( $parts as $p ) {
		foreach ( explode( '|', $p ) as $x ) {
			$x = trim( $x, " \t\n\r\0\x0B-*•·" );
			if ( '' !== $x ) { $out[] = $x; }
		}
	}
	return $out;
}

/** Диалог из textarea: строки вида «Клиент: реплика». */
function hod_dialogue( $v ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $v ) as $line ) {
		$line = preg_replace( '/^\s*\d+\.\s*/u', '', trim( $line ) );
		if ( '' === $line ) { continue; }
		if ( preg_match( '/^(.{1,40}?)\s*[:-]\s*(.+)$/u', $line, $m ) ) {
			$out[] = array( 'who' => trim( $m[1] ), 'say' => trim( $m[2], "«»\" \t" ) );
		} else {
			$out[] = array( 'who' => '', 'say' => $line );
		}
	}
	return $out;
}

/**
 * Ветки (Pro): строки вида «А) условие - действие».
 * Багфикс 08.10.2026: раньше ветки, записанные в одну строку («А) ... Б) ... В) ...»),
 * парсились как одна ветка, и Pro-блок показывал «1 ветка» и длинную строку.
 * Теперь строка дополнительно режется по маркерам А) Б) В) Г) Д).
 */
function hod_branches( $v ) {
	$v = (string) $v;
	$lines = preg_split( '/\r\n|\r|\n/', $v );
	$flat  = array();
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) { continue; }
		// одна строка с несколькими маркерами - разрезаем
		if ( preg_match_all( '/[А-ЯA-Z0-9]\)\s*/u', $line, $mm ) > 1 ) {
			$chunks = preg_split( '/(?=[А-ЯA-Z0-9]\)\s)/u', $line );
			foreach ( $chunks as $ch ) {
				if ( '' !== trim( $ch ) ) { $flat[] = trim( $ch ); }
			}
			continue;
		}
		$flat[] = $line;
	}
	$out = array();
	foreach ( $flat as $line ) {
		if ( preg_match( '/^[А-ЯA-Z0-9]\)\s*(.+)$/u', $line, $m ) ) { $line = trim( $m[1] ); }
		$parts = preg_split( '/\s+[→]{1,2}\s+|\s+-\s+/u', $line, 2 );
		$out[] = array(
			'if'   => isset( $parts[0] ) ? trim( $parts[0] ) : $line,
			'then' => isset( $parts[1] ) ? trim( $parts[1] ) : '',
		);
	}
	return $out;
}

/** Тренажёр-развилки (Pro): строки «Ситуация | Верно | Неверно | Почему». */
function hod_drills( $v ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $v ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) { continue; }
		$p = array_map( 'trim', explode( '|', $line ) );
		$out[] = array(
			'case'   => isset( $p[0] ) ? $p[0] : $line,
			'right'  => isset( $p[1] ) ? $p[1] : '',
			'wrong'  => isset( $p[2] ) ? $p[2] : '',
			'why'    => isset( $p[3] ) ? $p[3] : '',
		);
	}
	return $out;
}

/** Счётчики Pro-материалов карточки: для тизера гостю (без отдачи содержимого). */
function hod_pro_counts( $id ) {
	$g = function ( $k ) use ( $id ) {
		return function_exists( 'get_field' ) ? (string) get_field( $k, $id ) : (string) hod_meta( $id, $k );
	};
	return array(
		'branches'   => count( hod_branches( $g( 'branches' ) ) ),
		'drills'     => count( hod_drills( $g( 'pro_drill' ) ) ),
		'templates'  => count( hod_lines( $g( 'pro_templates' ) ) ),
		'checklist'  => count( hod_lines( $g( 'pro_checklist' ) ) ),
		'pack'       => trim( $g( 'pro_pack' ) ),
		'chars'      => mb_strlen( $g( 'branches' ) ) + mb_strlen( $g( 'pro_drill' ) ) + mb_strlen( $g( 'pro_templates' ) ) + mb_strlen( $g( 'pro_checklist' ) ),
	);
}

function hod_meta( $id, $key, $default = '' ) {
	$v = get_post_meta( $id, $key, true );
	return ( '' === $v || null === $v ) ? $default : $v;
}

/** Цвет серии карточки. */
function hod_series_color( $id, $fallback = '#1B4DFF' ) {
	$t = get_the_terms( $id, 'series' );
	if ( $t && ! is_wp_error( $t ) ) {
		$c = get_term_meta( $t[0]->term_id, 'hod_color', true );
		if ( $c ) { return $c; }
	}
	return $fallback;
}

function hod_series( $id ) {
	$t = get_the_terms( $id, 'series' );
	return ( $t && ! is_wp_error( $t ) ) ? $t[0] : null;
}

/** Связанные карточки по кодам. */
function hod_related( $id, $limit = 3 ) {
	$codes = array_filter( array_map( 'trim', explode( ',', (string) hod_meta( $id, 'related_codes' ) ) ) );
	if ( ! $codes ) {
		$t = get_the_terms( $id, 'series' );
		if ( $t && ! is_wp_error( $t ) ) {
			$q = new WP_Query( array(
				'post_type' => 'situation', 'posts_per_page' => $limit + 1, 'post__not_in' => array( $id ),
				'tax_query' => array( array( 'taxonomy' => 'series', 'field' => 'term_id', 'terms' => $t[0]->term_id ) ),
				'orderby' => 'date', 'no_found_rows' => true,
			) );
			return array_slice( $q->posts, 0, $limit );
		}
		return array();
	}
	$q = new WP_Query( array(
		'post_type' => 'situation', 'posts_per_page' => $limit, 'post__not_in' => array( $id ),
		'meta_query' => array( array( 'key' => 'code', 'value' => $codes, 'compare' => 'IN' ) ),
		'no_found_rows' => true,
	) );
	return $q->posts;
}

function hod_duration( $id ) {
	$s = (int) hod_meta( $id, 'duration_sec', 30 );
	return sprintf( '%d:%02d', floor( $s / 60 ), $s % 60 );
}

/** Хлебные крошки. */
function hod_breadcrumbs() {
	if ( is_front_page() ) { return; }
	$items = array( array( 'url' => home_url( '/' ), 'name' => 'Главная' ) );
	if ( is_singular( 'situation' ) ) {
		$id = get_the_ID();
		$s  = hod_series( $id );
		if ( $s ) { $items[] = array( 'url' => get_term_link( $s ), 'name' => $s->name ); }
		$items[] = array( 'url' => '', 'name' => hod_meta( $id, 'code', get_the_title( $id ) ) );
	} elseif ( is_tax() ) {
		$t = get_queried_object();
		$items[] = array( 'url' => '', 'name' => $t->name );
	} elseif ( is_search() ) {
		$items[] = array( 'url' => '', 'name' => 'Поиск: ' . get_search_query() );
	} elseif ( is_singular() ) {
		$items[] = array( 'url' => '', 'name' => get_the_title() );
	}
	echo '<nav class="bread" aria-label="Хлебные крошки">';
	$last = count( $items ) - 1;
	foreach ( $items as $i => $it ) {
		if ( $i > 0 ) { echo ' / '; }
		if ( $i === $last || ! $it['url'] ) { echo '<span>' . esc_html( $it['name'] ) . '</span>'; }
		else { echo '<a href="' . esc_url( $it['url'] ) . '">' . esc_html( $it['name'] ) . '</a>'; }
	}
	echo '</nav>';
}

/** Счётчики для строки доверия на главной. */
function hod_counters() {
	$cards   = (int) wp_count_posts( 'situation' )->publish;
	$series  = (int) wp_count_terms( array( 'taxonomy' => 'series', 'hide_empty' => true ) );
	$objects = (int) wp_count_terms( array( 'taxonomy' => 'objection', 'hide_empty' => true ) );
	return array( 'cards' => $cards, 'series' => $series, 'objections' => $objects );
}

/** Ссылка на карточку источника. */
function hod_source_link( $id ) {
	$terms = get_the_terms( $id, 'source_tax' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		return array( 'name' => $terms[0]->name, 'url' => get_term_link( $terms[0] ) );
	}
	$title = hod_meta( $id, 'source_title' );
	return $title ? array( 'name' => $title, 'url' => '' ) : null;
}
