<?php
defined( 'ABSPATH' ) || exit;

/**
 * Поля карточки ситуации регистрируются кодом (локальные поля ACF).
 * Повторяющиеся списки храним в textarea по одной позиции на строку -
 * это работает в бесплатной версии ACF и легко импортируется из CSV.
 */
function hod_f( $name, $label, $type = 'text', $extra = array() ) {
	return array_merge( array(
		'key'   => 'field_hod_' . $name,
		'label' => $label,
		'name'  => $name,
		'type'  => $type,
	), $extra );
}

add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }

	$hint_line = ' - по одной позиции на строку';

	acf_add_local_field_group( array(
		'key' => 'group_hod_class', 'title' => '1 · Классификация', 'style' => 'default',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'code', 'Код ситуации *', 'text', array( 'required' => 1, 'instructions' => 'Формат: две буквы серии + дефис + три цифры, например PR-001', 'wrapper' => array( 'width' => '25' ) ) ),
			hod_f( 'access_level', 'Доступ *', 'select', array( 'required' => 1, 'choices' => array( 'free' => 'Free', 'pro' => 'Pro' ), 'default_value' => 'free', 'wrapper' => array( 'width' => '25' ) ) ),
			hod_f( 'legal_risk_level', 'Юридический риск *', 'select', array( 'required' => 1, 'choices' => array( 'Low' => 'Low', 'Medium' => 'Medium', 'High' => 'High' ), 'default_value' => 'Low', 'wrapper' => array( 'width' => '25' ) ) ),
			hod_f( 'quality_score', 'Quality Score (0-100)', 'number', array( 'min' => 0, 'max' => 100, 'wrapper' => array( 'width' => '25' ) ) ),
			hod_f( 'difficulty', 'Сложность', 'select', array( 'choices' => array( 'Базовая' => 'Базовая', 'Средняя' => 'Средняя', 'Высокая' => 'Высокая' ) ) ),
			hod_f( 'counterpart_type', 'Тип собеседника', 'select', array( 'choices' => array( 'клиент' => 'Клиент', 'закупщик' => 'Закупщик', 'ассистент' => 'Ассистент/секретарь', 'команда' => 'Команда', 'совет' => 'Совет/партнёры', 'сотрудник' => 'Сотрудник', 'кандидат' => 'Кандидат', 'аудитория' => 'Аудитория/рынок' ), 'instructions' => 'Обязательно сверять с доменом: в маркетинге и управлении собеседник - не «клиент».' ) ),
			hod_f( 'counterpart', 'Кто собеседник (описание)', 'text' ),
			hod_f( 'channel', 'Канал', 'text', array( 'instructions' => 'Звонок / встреча / email / мессенджер / внутренняя сессия' ) ),
			hod_f( 'region_context', 'Рынок', 'select', array( 'choices' => array( 'RU' => 'RU', 'CIS' => 'CIS', 'Global' => 'Global' ), 'default_value' => 'RU' ) ),
			hod_f( 'status_wf', 'Статус в работе *', 'select', array( 'required' => 1, 'choices' => array( 'raw' => 'raw (сырьё)', 'draft' => 'draft', 'source_verified' => 'source_verified', 'expert_verified' => 'expert_verified', 'legal_cleared' => 'legal_cleared', 'ready' => 'ready', 'published' => 'published', 'retired' => 'retired' ), 'default_value' => 'draft' ) ),
			hod_f( 'last_reviewed', 'Дата последней проверки', 'date_picker', array( 'display_format' => 'd.m.Y', 'return_format' => 'Y-m-d' ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_sit', 'title' => '2 · Ситуация',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'situation_one_liner', 'Ситуация одной строкой', 'text' ),
			hod_f( 'counterpart_line', 'Дословная реплика собеседника *', 'text', array( 'required' => 1, 'instructions' => 'Это H1 карточки. Только живая фраза, не описание барьера.' ) ),
			hod_f( 'context_setup', 'Контекст: кто, где, что уже произошло', 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'stake', 'Что на кону', 'textarea', array( 'rows' => 2 ) ),
			hod_f( 'common_mistake', 'Типичная ошибка', 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'dont_say', 'Так говорить нельзя' . $hint_line, 'textarea', array( 'rows' => 4 ) ),
			hod_f( 'insight_why', 'Почему так происходит (механика)', 'textarea', array( 'rows' => 3 ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_method', 'title' => '3 · Приём и источник',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'framework_name_own', 'Название приёма (наше) *', 'text', array( 'required' => 1 ) ),
			hod_f( 'attribution_mode', 'Режим атрибуции *', 'select', array( 'required' => 1, 'choices' => array(
				'canonical_term' => 'canonical_term - канонический термин источника',
				'adapted_inspired_by' => 'adapted_inspired_by - адаптация по мотивам',
				'own_framework' => 'own_framework - собственный приём',
				'practitioner_interview' => 'practitioner_interview - из интервью с практиком',
				'regulation' => 'regulation - нормативный акт',
			) ) ),
			hod_f( 'framework_origin', 'Суть идеи своими словами', 'textarea', array( 'rows' => 2 ) ),
			hod_f( 'source_title', 'Источник: название', 'text', array( 'wrapper' => array( 'width' => '40' ) ) ),
			hod_f( 'source_author', 'Источник: автор', 'text', array( 'wrapper' => array( 'width' => '30' ) ) ),
			hod_f( 'source_year', 'Год', 'text', array( 'wrapper' => array( 'width' => '30' ) ) ),
			hod_f( 'source_page_chapter', 'Страница / глава (сверено по лицензионной копии)', 'text', array( 'instructions' => 'Обязательно для canonical_term. Публично не выводится, если не заполнено.' ) ),
			hod_f( 'applicability_limits', 'Границы применимости', 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'counter_examples', 'Когда приём НЕ работает', 'textarea', array( 'rows' => 2 ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_dlg', 'title' => '4 · Диалог и результат',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'dialogue_turns', 'Диалог: строки вида «Клиент: реплика»', 'textarea', array( 'rows' => 8 ) ),
			hod_f( 'key_questions', 'Ключевые вопросы' . $hint_line, 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'branches', 'Ветки (PRO): «А) условие - действие»' . $hint_line, 'textarea', array( 'rows' => 4, 'instructions' => 'Отдаётся только пользователям с доступом Pro.' ) ),
			hod_f( 'next_step', 'Следующий шаг *', 'textarea', array( 'required' => 1, 'rows' => 2 ) ),
			hod_f( 'micro_commitment', 'Микро-обязательство (дата/формат)', 'text' ),
			hod_f( 'desired_outcome', 'Результат', 'textarea', array( 'rows' => 2 ) ),
			hod_f( 'success_metrics', 'Метрики успеха' . $hint_line, 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'failure_signals', 'Признаки, что не сработало' . $hint_line, 'textarea', array( 'rows' => 3 ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_video', 'title' => '5 · Видео',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'video_url', 'URL видео (YouTube / VK / Rutube)', 'url' ),
			hod_f( 'video_mp4', 'Файл MP4 (для Pro-скачивания)', 'file', array( 'return_format' => 'url' ) ),
			hod_f( 'duration_sec', 'Длительность, сек (макс. 30)', 'number', array( 'default_value' => 30, 'min' => 10, 'max' => 30, 'instructions' => 'Жёсткий лимит проекта - 30 секунд. Озвучка 380-450 знаков.' ) ),
			hod_f( 'beat_structure', 'Каркас ролика', 'select', array( 'choices' => array(
				'BS1' => 'BS1 · Ошибка → приём',
				'BS2' => 'BS2 · Слабый и сильный ответ',
				'BS3' => 'BS3 · Вопрос-развилка',
				'BS4' => 'BS4 · До и после',
				'BS5' => 'BS5 · Один вопрос, который меняет всё',
				'BS6' => 'BS6 · Живой разбор практика',
			), 'default_value' => 'BS1' ) ),
			hod_f( 'hook_0_2s', 'Хук первых 2 секунд', 'text' ),
			hod_f( 'hook_variants', 'Варианты хука' . $hint_line, 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'vo_script_full', 'Текст озвучки (380-450 знаков)', 'textarea', array( 'rows' => 6 ) ),
			hod_f( 'vo_char_count', 'Знаков в озвучке (считается автоматически)', 'number', array( 'readonly' => 1 ) ),
			hod_f( 'on_screen_text', 'Текст на экране (по битам)', 'textarea', array( 'rows' => 4 ) ),
			hod_f( 'visual_concept', 'Визуальная концепция', 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'subtitles_vtt', 'Файл субтитров .vtt', 'file', array( 'return_format' => 'url' ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_pub', 'title' => '6 · Публикация, SEO, связи',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'related_codes', 'Связанные коды (через запятую)', 'text' ),
			hod_f( 'library_link_text', 'Текст Library Link', 'text' ),
			hod_f( 'seo_title', 'SEO title (≤60 знаков)', 'text' ),
			hod_f( 'meta_description', 'Meta description (≤155 знаков)', 'textarea', array( 'rows' => 2 ) ),
			hod_f( 'wp_tags', 'Теги (через запятую)', 'text' ),
			hod_f( 'disclaimer_text', 'Дисклеймер карточки', 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'legal_checks', 'Пройденные проверки (через запятую)', 'text', array( 'instructions' => 'АП, ТЗ, реклама, ПДн, AI-раскрытие, антимонопольное, ТК РФ' ) ),
			hod_f( 'consent_ref', 'Реестр согласий (для интервью)', 'text' ),
			hod_f( 'experience_overlay', 'Служебное: что заменить личным опытом (на сайт не выводится)', 'textarea', array( 'rows' => 2 ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_pro', 'title' => '8 · Pro-материалы (отдаются только с доступом Pro)',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ) ) ),
		'fields' => array(
			hod_f( 'pro_pack', 'Пак инструментов серии', 'text', array( 'instructions' => 'Например: PACK-PR «Цена и скидка»: калькулятор, матрица обмена, письмо-фиксация' ) ),
			hod_f( 'pro_templates', 'Готовые формулировки (Pro)' . $hint_line, 'textarea', array( 'rows' => 6, 'instructions' => 'Письма, сообщения, фразы. По одной формулировке на строку. Отдаётся только с доступом Pro.' ) ),
			hod_f( 'pro_checklist', 'Чек-лист подготовки (Pro)' . $hint_line, 'textarea', array( 'rows' => 6, 'instructions' => '5-7 пунктов, что сделать до разговора.' ) ),
			hod_f( 'pro_drill', 'Тренажёр-развилки (Pro)' . $hint_line, 'textarea', array( 'rows' => 6, 'instructions' => 'Формат: Ситуация | Верно | Неверно | Почему. Три развилки на карточку. Импорт в тренажёр без переделки.' ) ),
			hod_f( 'pro_files', 'Файлы Pro (PDF, xlsx, Notion)', 'text', array( 'instructions' => 'URL через запятую. Отдаются только с доступом Pro, проверяется hod_is_pro().' ) ),
			hod_f( 'pro_assets_status', 'Готовность Pro-материалов', 'select', array( 'choices' => array( '' => 'не задано', 'ready' => 'ready', 'draft' => 'draft', 'todo' => 'todo' ), 'default_value' => 'todo' ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_pm', 'title' => '7 · Управление персоналом (домен PM)',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'situation' ), array( 'param' => 'post_taxonomy', 'operator' => '==', 'value' => 'domain:people' ) ) ),
		'fields' => array(
			hod_f( 'pm_subject', 'С кем разговор', 'select', array( 'choices' => array( 'сотрудник' => 'Сотрудник', 'кандидат' => 'Кандидат', 'команда' => 'Команда', 'подчинённый руководитель' => 'Подчинённый руководитель', 'собственник' => 'Собственник' ) ) ),
			hod_f( 'pm_legal_ref', 'Норма ТК РФ (статья и дата проверки редакции)', 'text', array( 'instructions' => 'Например: ст. 192-193 ТК РФ, ред. от 01.09.2026' ) ),
			hod_f( 'pm_doc_required', 'Какой кадровый документ нужен', 'text' ),
			hod_f( 'pm_ethics_flag', 'Ситуация на границе допустимого', 'true_false' ),
			hod_f( 'pm_confidentiality', 'Уровень чувствительности примера', 'select', array( 'choices' => array( 'низкий' => 'низкий', 'средний' => 'средний (нужно обезличивание)', 'высокий' => 'высокий (только синтетика)' ) ) ),
		),
	) );

	acf_add_local_field_group( array(
		'key' => 'group_hod_src', 'title' => 'Источник (CPT source)',
		'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'source' ) ) ),
		'fields' => array(
			hod_f( 'source_type', 'Тип источника', 'select', array( 'choices' => array( 'book' => 'Книга', 'research' => 'Исследование', 'interview' => 'Интервью с практиком', 'regulation' => 'Нормативный акт', 'internal_case' => 'Собственный кейс' ) ) ),
			hod_f( 'source_author2', 'Автор', 'text', array( 'wrapper' => array( 'width' => '50' ) ) ),
			hod_f( 'source_year2', 'Год', 'text', array( 'wrapper' => array( 'width' => '25' ) ) ),
			hod_f( 'source_edition', 'Издание', 'text', array( 'wrapper' => array( 'width' => '25' ) ) ),
			hod_f( 'legally_obtained', 'Получен легально', 'true_false', array( 'instructions' => 'Обязательно для публикации карточек со статусом source_verified' ) ),
			hod_f( 'acquisition_proof', 'Где и когда приобретено (служебное)', 'text' ),
			hod_f( 'canonical_terms', 'Канонические термины источника' . $hint_line, 'textarea', array( 'rows' => 5 ) ),
			hod_f( 'buy_links', 'Легальные точки покупки: «Магазин - URL»' . $hint_line, 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'rights_notes', 'Права и товарные знаки (юрисдикции, дата проверки)', 'textarea', array( 'rows' => 3 ) ),
			hod_f( 'verified_by', 'Проверил', 'text', array( 'wrapper' => array( 'width' => '50' ) ) ),
			hod_f( 'verified_date', 'Дата проверки', 'date_picker', array( 'display_format' => 'd.m.Y', 'return_format' => 'Y-m-d', 'wrapper' => array( 'width' => '50' ) ) ),
		),
	) );
} );

/** Автоматический подсчёт знаков озвучки + предупреждение о лимите 30 секунд. */
add_action( 'acf/save_post', function ( $post_id ) {
	if ( 'situation' !== get_post_type( $post_id ) ) { return; }
	if ( function_exists( 'get_field' ) ) {
		$vo = (string) get_field( 'vo_script_full', $post_id );
		update_post_meta( $post_id, 'vo_char_count', mb_strlen( trim( $vo ) ) );
	}
}, 15 );

add_action( 'admin_notices', function () {
	if ( ! function_exists( 'get_current_screen' ) ) { return; }
	$s = get_current_screen();
	if ( ! $s || 'situation' !== $s->post_type ) { return; }
	global $post;
	if ( ! $post ) { return; }
	$len = (int) get_post_meta( $post->ID, 'vo_char_count', true );
	if ( $len > 450 ) {
		echo '<div class="notice notice-warning"><p><strong>ХОД:</strong> озвучка ' . esc_html( $len ) . ' знаков - это больше 30 секунд (лимит проекта). Сократите до 380-450 знаков.</p></div>';
	}
	if ( get_post_meta( $post->ID, 'attribution_mode', true ) === 'canonical_term' && '' === (string) get_post_meta( $post->ID, 'source_page_chapter', true ) ) {
		echo '<div class="notice notice-warning"><p><strong>ХОД:</strong> режим «канонический термин» требует указания страницы или главы источника.</p></div>';
	}
} );
