<?php
/**
 * Личный кабинет Pro, сохранённые карточки, выдача доступа после оплаты.
 *
 * Что здесь:
 *  1. Сохранённые карточки (user meta hod_saved) + AJAX-переключатель.
 *  2. Пауза и возобновление доступа (hod_paused_until).
 *  3. Webhook Robokassa (REST hod/v1/robokassa) с проверкой подписи MD5.
 *  4. Webhook YooKassa (REST hod/v1/yookassa) с Basic Auth и повторной проверкой платежа через API.
 *  5. Настройки платежей в админке (Библиотека -> Настройки Pro).
 *
 * Продавец - самозанятый (НПД): чеки формирует платёжный сервис, тема доступ только выдаёт.
 */
defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ 1. Доступ */

/** Сколько дней доступа даёт сумма платежа. Цены синхронизированы с tpl-pro.php. */
function hod_days_by_amount( $sum, $level = 'pro' ) {
	$sum = round( (float) $sum );
	$map = array(
		'pro'  => array( 99 => 30, 390 => 30, 590 => 30, 3900 => 365, 5900 => 365 ),
		'team' => array( 4900 => 30, 49000 => 365 ),
	);
	$prices = isset( $map[ $level ] ) ? $map[ $level ] : $map['pro'];
	foreach ( $prices as $price => $days ) {
		if ( abs( $price - $sum ) <= max( 1, round( $price * 0.03 ) ) ) { return $days; }
	}
	return $sum >= 3000 ? 365 : 30;
}

/** Уровень по сумме: 4900 и выше - team. */
function hod_level_by_amount( $sum ) {
	return round( (float) $sum ) >= 4900 ? 'team' : 'pro';
}

/**
 * Выдать или продлить доступ по email. Если пользователя нет - создаём и отправляем
 * ссылку на установку пароля (покупатель не обязан регистрироваться заранее).
 * Дни не сгорают: если доступ ещё действует, новый срок добавляется к текущему.
 */
function hod_grant_by_email( $email, $days = 30, $level = 'pro' ) {
	$email = sanitize_email( (string) $email );
	if ( ! is_email( $email ) ) { return new WP_Error( 'bad_email', 'Некорректный email' ); }

	$user = get_user_by( 'email', $email );
	$created = false;
	if ( ! $user ) {
		$base  = sanitize_user( preg_replace( '/[^A-Za-z0-9._-]/', '', substr( $email, 0, strpos( $email, '@' ) ) ), true );
		$login = $base ? $base : 'hod';
		$i     = 0;
		while ( get_user_by( 'login', $login ) ) { $i++; $login = $base . $i; }
		$uid = wp_create_user( $login, wp_generate_password( 16, true, true ), $email );
		if ( is_wp_error( $uid ) ) { return $uid; }
		$user    = get_user_by( 'id', $uid );
		$created = true;
		$key     = get_password_reset_key( $user );
		if ( ! is_wp_error( $key ) ) {
			$link = network_site_url( 'wp-login.php?action=rp&key=' . rawurlencode( $key ) . '&login=' . rawurlencode( $user->user_login ), 'login' );
			wp_mail(
				$email,
				'ХОД: доступ Pro открыт',
				"Оплата получена, доступ Pro открыт на {$days} дн.\n\n"
				. 'Войти и задать пароль: ' . $link . "\n\n"
				. 'Личный кабинет: ' . home_url( '/account/' ) . "\n"
				. 'Каталог: ' . home_url( '/catalog/' ) . "\n\n"
				. 'Чек самозанятого пришлёт платёжный сервис отдельным письмом.'
			);
		}
	}

	$cur  = get_user_meta( $user->ID, 'hod_access_until', true );
	$base = ( $cur && strtotime( $cur ) > current_time( 'timestamp' ) ) ? strtotime( $cur ) : current_time( 'timestamp' );
	$until = date( 'Y-m-d H:i:s', $base + ( $days * DAY_IN_SECONDS ) );

	update_user_meta( $user->ID, 'hod_access_until', $until );
	update_user_meta( $user->ID, 'hod_access_level', $level );
	delete_user_meta( $user->ID, 'hod_paused_until' );
	delete_user_meta( $user->ID, 'hod_cancelled' );
	update_user_meta( $user->ID, 'hod_last_payment', array( 'date' => current_time( 'mysql' ), 'days' => (int) $days, 'level' => $level ) );

	do_action( 'hod_access_granted', $user->ID, (int) $days, $level, $created );
	return $user->ID;
}

/* ------------------------------------------------- 2. Пауза влияет на hod_is_pro */

/** Пауза приостанавливает Pro, не сжигая оплаченные дни. */
function hod_is_paused( $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	$p = get_user_meta( $uid, 'hod_paused_until', true );
	return $p && strtotime( $p ) > current_time( 'timestamp' );
}

/** Robokassa ждёт текст вида OK123 без JSON-кавычек. */
function hod_plain_response( $text ) {
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo esc_html( $text );
	exit;
}

/* ------------------------------------------------------------- 3. Robokassa */

add_action( 'rest_api_init', function () {
	register_rest_route( 'hod/v1', '/robokassa', array(
		'methods'             => 'POST',
		'callback'            => 'hod_rest_robokassa',
		'permission_callback' => '__return_true',
	) );
	register_rest_route( 'hod/v1', '/yookassa', array(
		'methods'             => 'POST',
		'callback'            => 'hod_rest_yookassa',
		'permission_callback' => '__return_true',
	) );
} );

/**
 * Result URL Robokassa. Формат подписи: MD5(OutSum:InvId:Password2).
 * Ответ должен быть вида OK{InvId}, иначе Robokassa повторяет запрос.
 */
function hod_rest_robokassa( $request ) {
	$p     = $request->get_params();
	$out   = isset( $p['OutSum'] ) ? (float) $p['OutSum'] : 0;
	$inv   = isset( $p['InvId'] ) ? (int) $p['InvId'] : 0;
	$sig   = isset( $p['SignatureValue'] ) ? strtoupper( sanitize_text_field( wp_unslash( $p['SignatureValue'] ) ) ) : '';
	$email = isset( $p['Email'] ) ? sanitize_email( wp_unslash( $p['Email'] ) ) : '';
	$pass2 = (string) get_option( 'hod_rk_password2', '' );

	if ( '' === $pass2 ) {
		return new WP_Error( 'not_configured', 'Robokassa не настроена (Библиотека -> Настройки Pro)', array( 'status' => 501 ) );
	}
	$calc = strtoupper( md5( $out . ':' . $inv . ':' . $pass2 ) );
	if ( ! hash_equals( $calc, $sig ) ) {
		hod_payment_log( 'robokassa_bad_signature', array( 'inv' => $inv, 'sum' => $out ) );
		return new WP_Error( 'bad_signature', 'Подпись не совпала', array( 'status' => 403 ) );
	}
	if ( get_option( 'hod_paid_inv_' . $inv ) ) {
		hod_plain_response( 'OK' . $inv ); // повторный запрос, доступ уже выдан
	}
	update_option( 'hod_paid_inv_' . $inv, time(), false );

	$level = isset( $p['level'] ) && 'team' === $p['level'] ? 'team' : hod_level_by_amount( $out );
	$days  = hod_days_by_amount( $out, $level );
	$uid   = hod_grant_by_email( $email, $days, $level );
	hod_payment_log( 'robokassa_ok', array( 'inv' => $inv, 'sum' => $out, 'email' => $email, 'days' => $days, 'user' => is_wp_error( $uid ) ? 0 : $uid ) );

	hod_plain_response( 'OK' . $inv );
}

/* ------------------------------------------------------------- 4. YooKassa */

/**
 * Webhook YooKassa: событие payment.succeeded.
 * Проверяем Basic Auth (shopId:секретный ключ), затем повторно запрашиваем платёж
 * через API - тело вебхука само по себе не является доказательством оплаты.
 */
function hod_rest_yookassa( $request ) {
	$shop   = (string) get_option( 'hod_yk_shop_id', '' );
	$secret = (string) get_option( 'hod_yk_secret', '' );
	if ( '' === $shop || '' === $secret ) {
		return new WP_Error( 'not_configured', 'YooKassa не настроена', array( 'status' => 501 ) );
	}

	$auth = (string) $request->get_header( 'authorization' );
	$ok   = false;
	if ( $auth && 0 === stripos( $auth, 'Basic ' ) ) {
		$decoded = (string) base64_decode( substr( $auth, 6 ) );
		$ok = hash_equals( $shop . ':' . $secret, $decoded );
	}
	if ( ! $ok ) {
		hod_payment_log( 'yookassa_unauthorized', array() );
		return new WP_Error( 'unauthorized', 'Нет доступа', array( 'status' => 401 ) );
	}

	$body = json_decode( (string) $request->get_body(), true );
	if ( ! is_array( $body ) || empty( $body['object']['id'] ) ) {
		return rest_ensure_response( 'ignored' );
	}
	$payment_id = sanitize_text_field( $body['object']['id'] );
	if ( get_option( 'hod_paid_yk_' . md5( $payment_id ) ) ) {
		return rest_ensure_response( 'ok' );
	}

	$resp = wp_remote_get( 'https://api.yookassa.ru/v3/payments/' . rawurlencode( $payment_id ), array(
		'timeout' => 15,
		'headers' => array( 'Authorization' => 'Basic ' . base64_encode( $shop . ':' . $secret ) ),
	) );
	if ( is_wp_error( $resp ) ) {
		hod_payment_log( 'yookassa_api_error', array( 'id' => $payment_id, 'err' => $resp->get_error_message() ) );
		return new WP_Error( 'api_error', 'Не удалось проверить платёж', array( 'status' => 502 ) );
	}
	$pay = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
	if ( ! is_array( $pay ) || ! isset( $pay['status'] ) || 'succeeded' !== $pay['status'] ) {
		return rest_ensure_response( 'ignored' );
	}

	$sum   = isset( $pay['amount']['value'] ) ? (float) $pay['amount']['value'] : 0;
	$email = '';
	if ( ! empty( $pay['metadata']['user_email'] ) ) { $email = sanitize_email( $pay['metadata']['user_email'] ); }
	if ( '' === $email && ! empty( $pay['receipt']['customer']['email'] ) ) { $email = sanitize_email( $pay['receipt']['customer']['email'] ); }
	if ( '' === $email ) {
		hod_payment_log( 'yookassa_no_email', array( 'id' => $payment_id, 'sum' => $sum ) );
		return new WP_Error( 'no_email', 'В платеже нет email покупателя', array( 'status' => 422 ) );
	}

	$level = ( ! empty( $pay['metadata']['level'] ) && 'team' === $pay['metadata']['level'] ) ? 'team' : hod_level_by_amount( $sum );
	$days  = hod_days_by_amount( $sum, $level );
	$uid   = hod_grant_by_email( $email, $days, $level );
	update_option( 'hod_paid_yk_' . md5( $payment_id ), time(), false );
	hod_payment_log( 'yookassa_ok', array( 'id' => $payment_id, 'sum' => $sum, 'email' => $email, 'days' => $days, 'user' => is_wp_error( $uid ) ? 0 : $uid ) );

	return rest_ensure_response( 'ok' );
}

/** Простой журнал платежей в опциях (последние 50 записей), для сверки без плагинов. */
function hod_payment_log( $event, $data = array() ) {
	$log = (array) get_option( 'hod_payment_log', array() );
	array_unshift( $log, array( 'time' => current_time( 'mysql' ), 'event' => $event ) + $data );
	$log = array_slice( $log, 0, 50 );
	update_option( 'hod_payment_log', $log, false );
}

/* --------------------------------------------------- 5. AJAX: сохранить, пауза */

add_action( 'wp_ajax_hod_save', 'hod_ajax_save' );
function hod_ajax_save() {
	check_ajax_referer( 'hod_front', 'nonce' );
	if ( ! is_user_logged_in() ) {
		$back = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : home_url( '/' );
		wp_send_json_error( array( 'msg' => 'Войдите, чтобы сохранять карточки', 'login' => wp_login_url( $back ) ) );
	}
	$id    = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$uid   = get_current_user_id();
	$saved = (array) get_user_meta( $uid, 'hod_saved', true );
	$saved = array_values( array_filter( array_map( 'absint', $saved ) ) );
	$key   = array_search( $id, $saved, true );
	if ( false === $key ) { $saved[] = $id; $on = true; } else { unset( $saved[ $key ] ); $on = false; }
	update_user_meta( $uid, 'hod_saved', array_values( array_map( 'absint', $saved ) ) );
	wp_send_json_success( array( 'saved' => $on, 'count' => count( $saved ), 'msg' => $on ? 'Карточка в сохранённых' : 'Убрано из сохранённых' ) );
}

add_action( 'wp_ajax_hod_access_op', 'hod_ajax_access' );
function hod_ajax_access() {
	check_ajax_referer( 'hod_front', 'nonce' );
	if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'msg' => 'Нужен вход' ) ); }
	$uid = get_current_user_id();
	$op  = isset( $_POST['op'] ) ? sanitize_key( $_POST['op'] ) : '';

	if ( 'pause' === $op ) {
		$cur = (string) get_user_meta( $uid, 'hod_access_until', true );
		if ( ! $cur || strtotime( $cur ) < current_time( 'timestamp' ) ) {
			wp_send_json_error( array( 'msg' => 'Активного доступа нет, пауза не нужна.' ) );
		}
		$months = isset( $_POST['months'] ) ? min( 3, max( 1, (int) $_POST['months'] ) ) : 1;
		update_user_meta( $uid, 'hod_paused_until', date( 'Y-m-d H:i:s', strtotime( "+{$months} month", current_time( 'timestamp' ) ) ) );
		update_user_meta( $uid, 'hod_access_until', date( 'Y-m-d H:i:s', strtotime( "+{$months} month", strtotime( $cur ) ) ) );
		wp_send_json_success( array( 'msg' => "Доступ поставлен на паузу на {$months} мес. Оплаченные дни перенесены." ) );
	}
	if ( 'resume' === $op ) {
		delete_user_meta( $uid, 'hod_paused_until' );
		wp_send_json_success( array( 'msg' => 'Пауза снята, доступ активен.' ) );
	}
	if ( 'cancel' === $op ) {
		update_user_meta( $uid, 'hod_cancelled', 1 );
		wp_send_json_success( array( 'msg' => 'Автопродление выключено. Доступ останется до конца оплаченного периода.' ) );
	}
	if ( 'uncancel' === $op ) {
		delete_user_meta( $uid, 'hod_cancelled' );
		wp_send_json_success( array( 'msg' => 'Автопродление включено.' ) );
	}
	wp_send_json_error( array( 'msg' => 'Неизвестная операция' ) );
}

/* ------------------------------------------------------- 6. Настройки в админке */

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=situation', 'Настройки Pro', 'Настройки Pro', 'manage_options', 'hod-pro-settings', 'hod_pro_settings_page' );
} );

function hod_pro_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Нет прав' ); }
	if ( isset( $_POST['hod_save_settings'] ) && check_admin_referer( 'hod_settings' ) ) {
		update_option( 'hod_rk_password2', sanitize_text_field( wp_unslash( $_POST['rk2'] ?? '' ) ) );
		update_option( 'hod_yk_shop_id', sanitize_text_field( wp_unslash( $_POST['yk_shop'] ?? '' ) ) );
		update_option( 'hod_yk_secret', sanitize_text_field( wp_unslash( $_POST['yk_secret'] ?? '' ) ) );
		update_option( 'hod_account_page', sanitize_text_field( wp_unslash( $_POST['account_page'] ?? '/account/' ) ) );
		echo '<div class="notice notice-success"><p>Настройки сохранены.</p></div>';
	}
	$rk = (string) get_option( 'hod_rk_password2', '' );
	$ys = (string) get_option( 'hod_yk_shop_id', '' );
	$yc = (string) get_option( 'hod_yk_secret', '' );
	$ap = (string) get_option( 'hod_account_page', '/account/' );
	echo '<div class="wrap"><h1>Настройки Pro</h1>';
	echo '<form method="post">' . wp_nonce_field( 'hod_settings', '_wpnonce', true, false );
	echo '<table class="form-table">';
	echo '<tr><th>Robokassa: Password2</th><td><input class="regular-text" name="rk2" type="password" value="' . esc_attr( $rk ) . '"><p class="description">Из личного кабинета Robokassa. Result URL: <code>' . esc_url( rest_url( 'hod/v1/robokassa' ) ) . '</code></p></td></tr>';
	echo '<tr><th>YooKassa: shopId</th><td><input class="regular-text" name="yk_shop" type="text" value="' . esc_attr( $ys ) . '"></td></tr>';
	echo '<tr><th>YooKassa: секретный ключ</th><td><input class="regular-text" name="yk_secret" type="password" value="' . esc_attr( $yc ) . '"><p class="description">Webhook: <code>' . esc_url( rest_url( 'hod/v1/yookassa' ) ) . '</code>. Событие: <code>payment.succeeded</code>. В платёж передавайте <code>metadata.user_email</code> и <code>metadata.level</code>.</p></td></tr>';
	echo '<tr><th>URL личного кабинета</th><td><input class="regular-text" name="account_page" type="text" value="' . esc_attr( $ap ) . '"><p class="description">Страница с шаблоном «Личный кабинет Pro».</p></td></tr>';
	echo '</table><p><button class="button button-primary" name="hod_save_settings" value="1">Сохранить</button></p></form>';

	$log = (array) get_option( 'hod_payment_log', array() );
	echo '<h2>Журнал платежей (последние ' . count( $log ) . ')</h2>';
	if ( $log ) {
		echo '<table class="widefat striped"><thead><tr><th>Время</th><th>Событие</th><th>Данные</th></tr></thead><tbody>';
		foreach ( $log as $row ) {
			$t = isset( $row['time'] ) ? $row['time'] : '';
			$e = isset( $row['event'] ) ? $row['event'] : '';
			unset( $row['time'], $row['event'] );
			echo '<tr><td>' . esc_html( $t ) . '</td><td><code>' . esc_html( $e ) . '</code></td><td class="small">' . esc_html( wp_json_encode( $row, JSON_UNESCAPED_UNICODE ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
	} else {
		echo '<p class="description">Записей пока нет.</p>';
	}
	echo '</div>';
}

/** Ссылка на личный кабинет (учитывает настройку URL). */
function hod_account_url() {
	$p = (string) get_option( 'hod_account_page', '/account/' );
	return home_url( '/' . ltrim( $p, '/' ) );
}
