<?php
defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', function () {
	load_child_theme_textdomain( 'hod', HOD_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 220, 'flexible-width' => true ) );
	add_image_size( 'hod-card', 640, 360, true );
	add_image_size( 'hod-og', 1200, 630, true );
	register_nav_menus( array(
		'primary' => __( 'Основное меню', 'hod' ),
		'footer'  => __( 'Меню в подвале', 'hod' ),
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'hod-main', HOD_URI . '/assets/css/main.css', array(), HOD_VER );
	wp_enqueue_script( 'hod-main', HOD_URI . '/assets/js/main.js', array(), HOD_VER, true );
	wp_localize_script( 'hod-main', 'HOD', array(
		'ajax'  => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'hod_front' ),
		'home'  => home_url( '/' ),
	) );
} );

add_action( 'init', function () {
	register_post_type( 'hod_request', array(
		'label'        => 'Заявки ситуаций',
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'edit.php?post_type=situation',
		'supports'     => array( 'title', 'editor', 'custom-fields' ),
		'capability_type' => 'post',
	) );
} );

/** Отключаем комментарии и эмодзи - не нужны, экономят запросы. */
add_action( 'init', function () {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
} );
add_filter( 'emoji_svg_url', '__return_false' );

/** Формы на фронте: подписка и «прислать ситуацию». */
add_action( 'wp_ajax_hod_form', 'hod_handle_form' );
add_action( 'wp_ajax_nopriv_hod_form', 'hod_handle_form' );
function hod_handle_form() {
	check_ajax_referer( 'hod_front', 'nonce' );
	$type  = isset( $_POST['ftype'] ) ? sanitize_key( $_POST['ftype'] ) : '';
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';

	if ( 'request' === $type ) {
		$line = isset( $_POST['line'] ) ? sanitize_textarea_field( wp_unslash( $_POST['line'] ) ) : '';
		if ( '' === $line ) {
			wp_send_json_error( array( 'msg' => 'Напишите реплику собеседника - без неё непонятно, что разбирать.' ) );
		}
		$id = wp_insert_post( array(
			'post_type'   => 'hod_request',
			'post_title'  => mb_substr( $line, 0, 80 ),
			'post_content' => $line,
			'post_status' => 'private',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_hod_name', $name );
			update_post_meta( $id, '_hod_email', $email );
			update_post_meta( $id, '_hod_role', isset( $_POST['role'] ) ? sanitize_text_field( wp_unslash( $_POST['role'] ) ) : '' );
			update_post_meta( $id, '_hod_context', isset( $_POST['context'] ) ? sanitize_textarea_field( wp_unslash( $_POST['context'] ) ) : '' );
			update_post_meta( $id, '_hod_consent', ! empty( $_POST['consent'] ) ? '1' : '0' );
			do_action( 'hod_request_created', $id );
		}
		wp_send_json_success( array( 'msg' => 'Приняли. Разберём ситуацию в одном из ближайших выпусков и напишем вам, если оставили email.' ) );
	}

	if ( 'subscribe' === $type ) {
		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'msg' => 'Проверьте email - похоже, в адресе опечатка.' ) );
		}
		global $wpdb;
		$table = $wpdb->prefix . 'hod_subscribers';
		$wpdb->query( "CREATE TABLE IF NOT EXISTS {$table} (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, email VARCHAR(190) NOT NULL, name VARCHAR(190) DEFAULT '', role VARCHAR(80) DEFAULT '', consent TINYINT(1) DEFAULT 0, created DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), UNIQUE KEY email (email)) DEFAULT CHARSET=utf8mb4" );
		$wpdb->replace( $table, array(
			'email'   => $email,
			'name'    => $name,
			'role'    => isset( $_POST['role'] ) ? sanitize_text_field( wp_unslash( $_POST['role'] ) ) : '',
			'consent' => ! empty( $_POST['consent'] ) ? 1 : 0,
		) );
		do_action( 'hod_subscriber_added', $email, $name );
		wp_send_json_success( array( 'msg' => 'Готово. Подтвердите подписку в письме - и забирайте 12 ситуаций.' ) );
	}

	wp_send_json_error( array( 'msg' => 'Неизвестная форма.' ) );
}

/** Экспорт подписчиков в CSV (для загрузки в Brevo/Sender/Unisender). */
add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=situation', 'Подписчики', 'Подписчики', 'manage_options', 'hod-subs', function () {
		global $wpdb;
		$table = $wpdb->prefix . 'hod_subscribers';
		if ( isset( $_GET['hod_export'] ) && current_user_can( 'manage_options' ) ) {
			$rows = $wpdb->get_results( "SELECT email,name,role,consent,created FROM {$table} ORDER BY id DESC", ARRAY_A );
			nocache_headers();
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=hod-subscribers.csv' );
			$out = fopen( 'php://output', 'w' );
			fwrite( $out, "\xEF\xBB\xBF" );
			fputcsv( $out, array( 'email', 'name', 'role', 'consent', 'created' ), ';' );
			foreach ( (array) $rows as $r ) { fputcsv( $out, $r, ';' ); }
			fclose( $out );
			exit;
		}
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		echo '<div class="wrap"><h1>Подписчики</h1><p>Всего: <strong>' . esc_html( $total ) . '</strong></p>';
		echo '<p><a class="button button-primary" href="' . esc_url( add_query_arg( 'hod_export', 1 ) ) . '">Скачать CSV</a> <span class="description">Загружается в Brevo / Sender / Unisender.</span></p></div>';
	} );
} );
