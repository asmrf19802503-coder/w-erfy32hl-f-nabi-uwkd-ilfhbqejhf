<?php
defined( 'ABSPATH' ) || exit;

/**
 * Импорт карточек из CSV (формат content/launch12_cards.csv).
 * Два входа: WP-CLI `wp hod import /path/file.csv` и страница в админке.
 */

function hod_import_row( array $r ) {
	$code = trim( (string) ( isset( $r['code'] ) ? $r['code'] : '' ) );
	if ( '' === $code ) { return new WP_Error( 'no_code', 'Нет кода карточки' ); }

	$title = trim( (string) ( isset( $r['post_title'] ) ? $r['post_title'] : $code ) );
	$slug  = trim( (string) ( isset( $r['slug'] ) ? $r['slug'] : '' ) );

	$existing = get_posts( array( 'post_type' => 'situation', 'name' => $slug ?: sanitize_title( $code ), 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) );
	$post_id  = $existing ? (int) $existing[0] : 0;

	$postarr = array(
		'post_type'   => 'situation',
		'post_status' => 'publish',
		'post_title'  => $title,
		'post_name'   => $slug ?: sanitize_title( $code ),
		'post_excerpt'=> isset( $r['situation_one_liner'] ) ? $r['situation_one_liner'] : '',
		'post_content'=> isset( $r['context_setup'] ) ? $r['context_setup'] : '',
	);
	if ( $post_id ) { $postarr['ID'] = $post_id; $post_id = wp_update_post( $postarr, true ); }
	else { $post_id = wp_insert_post( $postarr, true ); }
	if ( is_wp_error( $post_id ) ) { return $post_id; }

	// Метаполя: всё, кроме служебного experience_overlay (не публикуется, но хранится).
	$skip = array( 'code', 'post_title', 'slug', 'series', 'series_slug', 'objection', 'objection_slug', 'role', 'stage', 'domain', 'origin', 'origin_slug', 'wp_tags' );
	foreach ( $r as $k => $v ) {
		if ( in_array( $k, $skip, true ) || '' === trim( (string) $v ) ) { continue; }
		update_post_meta( $post_id, $k, wp_slash( $v ) );
	}
	update_post_meta( $post_id, 'code', $code );
	update_post_meta( $post_id, 'related_codes', isset( $r['related_ids'] ) ? $r['related_ids'] : '' );
	update_post_meta( $post_id, 'status_wf', ! empty( $r['status'] ) ? 'draft' : 'draft' );
	update_post_meta( $post_id, 'access_level', ! empty( $r['access_level'] ) ? $r['access_level'] : 'free' );
	update_post_meta( $post_id, 'duration_sec', ! empty( $r['duration_sec'] ) ? (int) $r['duration_sec'] : 30 );
	update_post_meta( $post_id, 'vo_char_count', mb_strlen( trim( (string) ( isset( $r['vo_script_full'] ) ? $r['vo_script_full'] : '' ) ) ) );

	// Таксономии.
	$map = array(
		'series'    => array( 'series', isset( $r['series'] ) ? $r['series'] : '', isset( $r['series_slug'] ) ? $r['series_slug'] : '' ),
		'objection' => array( 'objection', isset( $r['objection'] ) ? $r['objection'] : '', isset( $r['objection_slug'] ) ? $r['objection_slug'] : '' ),
		'role'      => array( 'role', isset( $r['role'] ) ? $r['role'] : '', '' ),
		'stage'     => array( 'stage', isset( $r['stage'] ) ? $r['stage'] : '', '' ),
		'domain'    => array( 'domain', isset( $r['domain'] ) ? $r['domain'] : '', '' ),
		'origin'    => array( 'origin', isset( $r['origin'] ) ? $r['origin'] : '', isset( $r['origin_slug'] ) ? $r['origin_slug'] : '' ),
	);
	foreach ( $map as $tax => $cfg ) {
		$name = trim( $cfg[1] );
		if ( '' === $name ) { continue; }
		$slug = $cfg[2] ? $cfg[2] : sanitize_title( $name );
		$term = get_term_by( 'slug', $slug, $tax );
		if ( ! $term ) {
			$res = wp_insert_term( $name, $tax, array( 'slug' => $slug ) );
			if ( is_wp_error( $res ) ) { $term = get_term_by( 'name', $name, $tax ); }
			else { $term = get_term( (int) $res['term_id'], $tax ); }
		}
		if ( $term && ! is_wp_error( $term ) ) { wp_set_object_terms( $post_id, array( (int) $term->term_id ), $tax ); }
	}

	// Теги.
	if ( ! empty( $r['wp_tags'] ) ) {
		$tags = array_map( 'trim', explode( ',', $r['wp_tags'] ) );
		wp_set_post_terms( $post_id, $tags, 'post_tag' );
	}

	// Цвет серии по умолчанию.
	$series_term = get_the_terms( $post_id, 'series' );
	if ( $series_term && ! is_wp_error( $series_term ) ) {
		$tid = $series_term[0]->term_id;
		if ( ! get_term_meta( $tid, 'hod_color', true ) ) {
			$code2 = strtoupper( substr( $code, 0, 2 ) );
			$colors = array( 'FC' => '#2563EB', 'DQ' => '#2563EB', 'PD' => '#2563EB', 'CC' => '#DC2626', 'AM' => '#2563EB', 'DS' => '#2563EB', 'CL' => '#2563EB', 'PR' => '#DC2626', 'NG' => '#DC2626', 'PS' => '#059669', 'LC' => '#059669', 'CW' => '#059669', 'PM' => '#7C3AED', 'MT' => '#7C3AED', 'PF' => '#7C3AED', 'RC' => '#7C3AED', 'MG' => '#7C3AED', 'ON' => '#7C3AED', 'LR' => '#7C3AED', 'CM' => '#7C3AED', 'LS' => '#0F766E' );
			update_term_meta( $tid, 'hod_color', isset( $colors[ $code2 ] ) ? $colors[ $code2 ] : '#1B4DFF' );
		}
	}

	return $post_id;
}

function hod_import_csv( $path ) {
	if ( ! is_readable( $path ) ) { return new WP_Error( 'no_file', 'Файл не найден: ' . $path ); }
	$fh = fopen( $path, 'r' );
	$head = fgetcsv( $fh, 0, ',' );
	if ( ! $head ) { return new WP_Error( 'empty', 'Пустой CSV' ); }
	// BOM
	$head[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $head[0] );
	$ok = 0; $err = array();
	while ( ( $row = fgetcsv( $fh, 0, ',' ) ) !== false ) {
		if ( count( $row ) < 3 ) { continue; }
		$data = array();
		foreach ( $head as $i => $k ) { $data[ trim( $k ) ] = isset( $row[ $i ] ) ? $row[ $i ] : ''; }
		$res = hod_import_row( $data );
		if ( is_wp_error( $res ) ) { $err[] = $res->get_error_message(); } else { $ok++; }
	}
	fclose( $fh );
	return array( 'imported' => $ok, 'errors' => $err );
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'hod import', function ( $args, $assoc ) {
		if ( empty( $args[0] ) ) { WP_CLI::error( 'Укажите путь к CSV: wp hod import /path/launch12_cards.csv' ); }
		$res = hod_import_csv( $args[0] );
		if ( is_wp_error( $res ) ) { WP_CLI::error( $res->get_error_message() ); }
		WP_CLI::success( 'Импортировано карточек: ' . $res['imported'] );
		foreach ( $res['errors'] as $e ) { WP_CLI::warning( $e ); }
	} );
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=situation', 'Импорт CSV', 'Импорт CSV', 'manage_options', 'hod-import', function () {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Нет прав' ); }
		$out = '';
		if ( ! empty( $_FILES['hod_csv'] ) && check_admin_referer( 'hod_import' ) ) {
			$f = $_FILES['hod_csv'];
			if ( 'csv' === pathinfo( $f['name'], PATHINFO_EXTENSION ) && $f['size'] > 0 ) {
				$res = hod_import_csv( $f['tmp_name'] );
				if ( is_wp_error( $res ) ) { $out = '<div class="notice notice-error"><p>' . esc_html( $res->get_error_message() ) . '</p></div>'; }
				else {
					$out = '<div class="notice notice-success"><p>Импортировано: <strong>' . (int) $res['imported'] . '</strong></p></div>';
					foreach ( $res['errors'] as $e ) { $out .= '<div class="notice notice-warning"><p>' . esc_html( $e ) . '</p></div>'; }
				}
			} else { $out = '<div class="notice notice-error"><p>Нужен файл .csv</p></div>'; }
		}
		echo '<div class="wrap"><h1>Импорт карточек из CSV</h1>' . $out;
		echo '<p>Формат - <code>content/launch12_cards.csv</code> (51 колонка). Существующие карточки обновляются по slug.</p>';
		echo '<form method="post" enctype="multipart/form-data">' . wp_nonce_field( 'hod_import', '_wpnonce', true, false );
		echo '<p><input type="file" name="hod_csv" accept=".csv" required></p><p><button class="button button-primary">Импортировать</button></p></form>';
		echo '<hr><p><strong>Проверка после импорта:</strong> у каждой карточки заполнены <code>code</code>, <code>counterpart_line</code>, <code>framework_name_own</code>, <code>attribution_mode</code>, <code>access_level</code>, <code>legal_risk_level</code>; <code>vo_char_count</code> ≤ 450.</p></div>';
	} );
} );
