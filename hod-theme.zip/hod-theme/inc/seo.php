<?php
defined( 'ABSPATH' ) || exit;

/**
 * SEO-вывод работает автономно и отключается, если активен Rank Math / Yoast,
 * чтобы не дублировать теги.
 */
function hod_seo_active() {
	return ! defined( 'RANK_MATH_VERSION' ) && ! defined( 'WPSEO_VERSION' );
}

function hod_seo_title() {
	if ( is_singular( 'situation' ) ) {
		$id = get_the_ID();
		$t  = hod_meta( $id, 'seo_title' );
		if ( $t ) { return $t; }
		$s = hod_series( $id );
		return sprintf( '«%s» - что ответить: приём и диалог%s | %s',
			get_the_title( $id ),
			$s ? ' · ' . $s->name : '',
			get_bloginfo( 'name' ) );
	}
	if ( is_tax( 'objection' ) ) { return 'Что ответить на «' . single_term_title( '', false ) . '» | ' . get_bloginfo( 'name' ); }
	if ( is_tax( 'series' ) ) { return single_term_title( '', false ) . ' - все ситуации серии | ' . get_bloginfo( 'name' ); }
	return '';
}

function hod_seo_description() {
	if ( is_singular( 'situation' ) ) {
		$id = get_the_ID();
		$d  = hod_meta( $id, 'meta_description' );
		if ( $d ) { return $d; }
		return wp_trim_words( wp_strip_all_tags( (string) hod_meta( $id, 'situation_one_liner' ) . ' ' . hod_meta( $id, 'common_mistake' ) ), 24, '…' );
	}
	if ( is_tax() ) { return wp_trim_words( wp_strip_all_tags( term_description() ), 26, '…' ); }
	return get_bloginfo( 'description' );
}

add_action( 'wp_head', function () {
	if ( ! hod_seo_active() ) { return; }
	$d = hod_seo_description();
	if ( $d ) { echo '<meta name="description" content="' . esc_attr( $d ) . '">' . "\n"; }
	if ( is_singular() ) {
		echo '<link rel="canonical" href="' . esc_url( get_permalink() ) . '">' . "\n";
		echo '<meta property="og:type" content="article">' . "\n";
	} elseif ( is_tax() || is_post_type_archive() ) {
		echo '<meta property="og:type" content="website">' . "\n";
	}
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
	if ( $d ) { echo '<meta property="og:description" content="' . esc_attr( $d ) . '">' . "\n"; }
	if ( is_singular() && has_post_thumbnail() ) {
		echo '<meta property="og:image" content="' . esc_url( get_the_post_thumbnail_url( null, 'hod-og' ) ) . '">' . "\n";
	}
}, 5 );

add_filter( 'pre_get_document_title', function ( $title ) {
	$t = hod_seo_title();
	return $t ? $t : $title;
}, 20 );

/** Structured data. */
add_action( 'wp_head', function () {
	if ( ! hod_seo_active() ) { return; }
	$data = array();

	if ( is_singular( 'situation' ) ) {
		$id  = get_the_ID();
		$url = get_permalink( $id );
		$data[] = array(
			'@context' => 'https://schema.org', '@type' => 'Article',
			'headline' => mb_substr( '«' . hod_meta( $id, 'counterpart_line', get_the_title( $id ) ) . '» - что ответить', 0, 110 ),
			'datePublished' => get_the_date( 'c', $id ),
			'dateModified'  => get_the_modified_date( 'c', $id ),
			'inLanguage' => 'ru-RU',
			'url' => $url,
			'about' => array( '@type' => 'Thing', 'name' => hod_meta( $id, 'framework_name_own' ) ),
		);
		$vid = hod_meta( $id, 'video_url' );
		if ( $vid ) {
			$data[] = array(
				'@context' => 'https://schema.org', '@type' => 'VideoObject',
				'name' => hod_meta( $id, 'counterpart_line', get_the_title( $id ) ),
				'description' => hod_seo_description(),
				'uploadDate' => get_the_date( 'c', $id ),
				'contentUrl' => $vid, 'embedUrl' => $vid,
				'duration' => 'PT' . max( 1, (int) hod_meta( $id, 'duration_sec', 30 ) ) . 'S',
				'thumbnailUrl' => has_post_thumbnail( $id ) ? get_the_post_thumbnail_url( $id, 'hod-card' ) : '',
				'inLanguage' => 'ru-RU',
			);
		}
	}

	if ( is_tax( 'objection' ) || is_singular( 'situation' ) ) {
		$faq = apply_filters( 'hod_faq_schema', array() );
		if ( $faq ) {
			$data[] = array(
				'@context' => 'https://schema.org', '@type' => 'FAQPage',
				'mainEntity' => array_map( function ( $q ) {
					return array( '@type' => 'Question', 'name' => $q['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $q['a'] ) );
				}, $faq ),
			);
		}
	}

	if ( is_tax( 'series' ) ) {
		$q = new WP_Query( array( 'post_type' => 'situation', 'posts_per_page' => 50, 'tax_query' => array( array( 'taxonomy' => 'series', 'field' => 'term_id', 'terms' => get_queried_object_id() ) ), 'no_found_rows' => true ) );
		$data[] = array(
			'@context' => 'https://schema.org', '@type' => 'ItemList',
			'name' => single_term_title( '', false ),
			'itemListElement' => array_values( array_map( function ( $p, $i ) {
				return array( '@type' => 'ListItem', 'position' => $i + 1, 'url' => get_permalink( $p ) );
			}, $q->posts, array_keys( $q->posts ) ) ),
		);
	}

	if ( ! is_front_page() ) {
		$crumbs = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Главная', 'item' => home_url( '/' ) ) );
		$crumbs[] = array( '@type' => 'ListItem', 'position' => 2, 'name' => wp_strip_all_tags( hod_seo_title() ? hod_seo_title() : get_the_title() ), 'item' => is_singular() ? get_permalink() : '' );
		$data[] = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs );
	}

	foreach ( $data as $block ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $block, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
	}
}, 6 );

/** Роботы: закрываем параметры фильтрации и служебные страницы. */
add_filter( 'wp_robots', function ( $robots ) {
	if ( is_search() || is_post_type_archive( 'hod_request' ) ) { $robots['noindex'] = true; $robots['follow'] = true; }
	if ( isset( $_GET['role'] ) || isset( $_GET['stage'] ) || isset( $_GET['access'] ) ) { $robots['noindex'] = true; $robots['follow'] = true; }
	return $robots;
} );
