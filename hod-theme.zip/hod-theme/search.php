<?php defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap" style="padding-top:28px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<h1 style="font-size:30px">Поиск: «<?php echo esc_html( get_search_query() ); ?>»</h1>
	<p class="muted">Найдено: <?php echo (int) $wp_query->found_posts; ?></p>
	<form class="searchbig" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="margin:18px 0 26px">
		<input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Реплика, приём или ситуация">
		<input type="hidden" name="post_type" value="situation"><button class="btn btn-p">Найти</button>
	</form>
	<?php if ( have_posts() ) : ?>
		<div class="grid g3"><?php while ( have_posts() ) : the_post();
			if ( 'situation' === get_post_type() ) { get_template_part( 'template-parts/card-situation' ); }
			else { echo '<div class="card pad"><div class="meta small muted">' . esc_html( get_post_type_object( get_post_type() )->labels->singular_name ) . '</div><div class="q" style="font-size:17px"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></div><div class="small muted">' . esc_html( wp_trim_words( get_the_excerpt(), 20 ) ) . '</div></div>'; }
		endwhile; ?></div>
		<div class="pagination"><?php echo paginate_links(); ?></div>
	<?php else : ?>
		<div class="card pad"><h3>Ничего не найдено</h3><p class="small muted">Опишите ситуацию своими словами - разберём её в ближайшем выпуске.</p>
		<p><a class="btn btn-p btn-s" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a> <a class="btn btn-o btn-s" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Открыть каталог</a></p></div>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
