<?php /* Template Name: Все возражения */ defined( 'ABSPATH' ) || exit; get_header();
$terms = get_terms( array( 'taxonomy' => 'objection', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) ); ?>
<div class="wrap" style="padding-top:30px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<h1 style="font-size:34px;max-width:22ch">Возражения и барьеры: что ответить</h1>
	<p class="lead muted" style="font-size:17px;margin-top:12px;max-width:70ch">Каждое возражение - отдельный раздел: короткий ответ, видео, все ситуации по теме и список фраз, которые говорить нельзя. Это самый быстрый путь к нужной карточке.</p>
	<div class="grid g3" style="margin-top:26px">
	<?php if ( $terms && ! is_wp_error( $terms ) ) : foreach ( $terms as $t ) : ?>
		<a class="card pad" href="<?php echo esc_url( get_term_link( $t ) ); ?>" style="text-decoration:none;color:inherit">
			<div class="meta small muted" style="margin-bottom:8px"><?php echo (int) $t->count; ?> ситуаций</div>
			<div class="q" style="font-size:18px">«<?php echo esc_html( $t->name ); ?>»</div>
			<?php if ( $t->description ) : ?><div class="small muted" style="margin-top:6px"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $t->description ), 16, '…' ) ); ?></div><?php endif; ?>
		</a>
	<?php endforeach; else : ?><div class="note" style="grid-column:1/-1">Термины возражений появятся после импорта карточек.</div><?php endif; ?>
	</div>
	<div class="card pad" style="margin-top:30px;background:var(--mist)">
		<h3>Не нашли своё возражение?</h3>
		<p class="small muted">Напишите дословную реплику собеседника - разберём в ближайшем выпуске и пришлём ссылку.</p>
		<a class="btn btn-p btn-s" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a>
	</div>
</div>
<?php get_footer(); ?>
