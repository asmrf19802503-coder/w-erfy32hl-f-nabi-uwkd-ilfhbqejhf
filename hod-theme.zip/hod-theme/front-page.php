<?php defined( 'ABSPATH' ) || exit; get_header(); $c = hod_counters(); ?>
<div class="hero">
	<div class="wrap">
		<h1><?php echo esc_html( get_theme_mod( 'hod_hero_title', 'Что сказать, когда клиент говорит «дорого»' ) ); ?></h1>
		<p class="lead"><?php echo esc_html( get_theme_mod( 'hod_hero_lead', 'Библиотека рабочих ситуаций в продажах, маркетинге и управлении. Одна ситуация - одна ошибка - один приём - готовый следующий шаг. 30 секунд на видео, полная карточка с ветками диалога на странице.' ) ); ?></p>
		<form class="searchbig" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="hod-hero-s">Поиск по ситуациям</label>
			<input id="hod-hero-s" type="search" name="s" placeholder="Введите реплику: «нет бюджета», «вы как все», «пришлите на почту»">
			<input type="hidden" name="post_type" value="situation">
			<button class="btn btn-p">Найти ситуацию</button>
		</form>
		<div class="suggest"><span class="xs muted">Частые запросы:</span>
			<?php
			$top = get_terms( array( 'taxonomy' => 'objection', 'hide_empty' => true, 'number' => 6, 'orderby' => 'count', 'order' => 'DESC' ) );
			if ( $top && ! is_wp_error( $top ) ) { foreach ( $top as $t ) { echo '<a class="chip" href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</a>'; } }
			?>
		</div>
		<div class="trustrow">
			<div><b><?php echo (int) $c['cards']; ?></b>ситуаций в библиотеке</div>
			<div><b>30 сек</b>средний ролик</div>
			<div><b><?php echo (int) $c['series']; ?></b>серий</div>
			<div><b><?php echo (int) $c['objections']; ?></b>возражений разобрано</div>
			<div><b>100%</b>с указанием источника</div>
		</div>
	</div>
</div>

<section class="blk"><div class="wrap">
	<div class="blk-h"><div><h2>Серии библиотеки</h2><p>Каждая серия - отдельный плейлист и раздел каталога. Цвет серии сквозной: в ролике, на карточке и в навигации.</p></div>
	<a class="btn btn-o btn-s" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Весь каталог</a></div>
	<div class="grid g4">
		<?php
		$series = get_terms( array( 'taxonomy' => 'series', 'hide_empty' => true, 'orderby' => 'name', 'order' => 'ASC' ) );
		if ( $series && ! is_wp_error( $series ) ) : foreach ( $series as $s ) :
			$col = get_term_meta( $s->term_id, 'hod_color', true ); if ( ! $col ) { $col = '#1B4DFF'; }
			$n = (int) $s->count;
			?>
			<a class="card scard" href="<?php echo esc_url( get_term_link( $s ) ); ?>" style="text-decoration:none;color:inherit">
				<div class="stripe" style="background:<?php echo esc_attr( $col ); ?>"></div>
				<div class="body">
					<div class="meta"><span class="seriesdot" style="background:<?php echo esc_attr( $col ); ?>"></span> <?php echo esc_html( $n ); ?> ситуаций</div>
					<div class="q"><?php echo esc_html( $s->name ); ?></div>
					<?php if ( $s->description ) : ?><div class="small muted"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $s->description ), 18, '…' ) ); ?></div><?php endif; ?>
				</div>
				<div class="foot"><span class="badge b-free">Free</span><span>Смотреть серию →</span></div>
			</a>
		<?php endforeach; endif; ?>
		<a class="card scard" href="<?php echo esc_url( home_url( '/pm/' ) ); ?>" style="text-decoration:none;color:inherit">
			<div class="stripe" style="background:var(--pm)"></div>
			<div class="body">
				<div class="meta"><span class="seriesdot dot-pm"></span> PM · Люди · 7 серий</div>
				<div class="q">Управление персоналом: подбор, обучение, мотивация</div>
				<div class="small muted">Разговор о прибавке без бюджета, выгорание сильного, токсичная звезда, увольнение, обучение без отрыва от работы.</div>
			</div>
			<div class="foot"><span class="badge b-pro">Pro</span><span>Что входит →</span></div>
		</a>
	</div>
</div></section>

<section class="blk" style="background:#fff;border-top:1px solid var(--line);border-bottom:1px solid var(--line)"><div class="wrap">
	<div class="blk-h"><div><h2>Как устроена каждая карточка</h2><p>Формат одинаковый во всей библиотеке: его можно прочитать за 30 секунд и применить на следующей встрече.</p></div></div>
	<div class="stepline">
		<div class="step"><b>1 · Реплика</b>Дословно то, что говорит собеседник</div>
		<div class="step"><b>2 · Ошибка</b>Что обычно отвечают и почему это проигрывает</div>
		<div class="step"><b>3 · Приём</b>Название и суть одной фразой</div>
		<div class="step"><b>4 · Диалог</b>4-6 реплик, которые можно произнести завтра</div>
		<div class="step"><b>5 · Ветки</b>Что делать, если ответят иначе <span class="badge b-pro" style="margin-left:4px">Pro</span></div>
		<div class="step"><b>6 · Результат</b>Что изменилось и конкретный следующий шаг</div>
		<div class="step"><b>7 · Источник</b>По мотивам чего и когда приём не работает</div>
	</div>
</div></section>

<section class="blk"><div class="wrap">
	<div class="blk-h"><div><h2>Последние ситуации</h2><p>Новое добавляется каждую неделю. Код ситуации сквозной: по нему находятся видео, карточка и связанные разборы.</p></div></div>
	<div class="grid g3">
		<?php
		$q = new WP_Query( array( 'post_type' => 'situation', 'posts_per_page' => 6, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) );
		while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'template-parts/card-situation' ); endwhile; wp_reset_postdata();
		if ( ! $q->post_count ) { echo '<div class="note" style="grid-column:1/-1">Карточек пока нет. Импортируйте CSV: <code>Библиотека → Импорт CSV</code> или <code>wp hod import /путь/launch12_cards.csv</code></div>'; }
		?>
	</div>
</div></section>

<?php get_template_part( 'template-parts/lead-magnet' ); ?>

<section class="blk"><div class="wrap"><div class="grid g3">
	<div class="card pad"><h3>Почему не «10 лайфхаков»</h3><p class="small muted">Каждая карточка - конкретная реплика конкретного собеседника в конкретной стадии сделки. Не теория метода и не мотивация, а что сказать в следующую секунду.</p></div>
	<div class="card pad"><h3>Почему можно верить</h3><p class="small muted">У каждой ситуации указан источник: книга, исследование, нормативный акт или интервью с практиком. Режим использования источника - публично, на странице «Метод».</p></div>
	<div class="card pad"><h3>Почему без обещаний</h3><p class="small muted">Диалоги и цифры - условные примеры. Приём может не сработать в вашем контексте, и в карточке прямо написано, когда он не работает.</p></div>
</div></div></section>
<?php get_footer(); ?>
