<?php get_template_part( 'archive', 'situation' ); ?>
