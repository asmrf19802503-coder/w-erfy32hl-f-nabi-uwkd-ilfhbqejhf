<?php defined( 'ABSPATH' ) || exit; get_header(); $t = get_queried_object();
$q = new WP_Query( array( 'post_type' => 'situation', 'posts_per_page' => 60, 'tax_query' => array( array( 'taxonomy' => 'source_tax', 'field' => 'term_id', 'terms' => $t->term_id ) ), 'no_found_rows' => true ) ); ?>
<div class="wrap" style="padding-top:28px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<h1 style="font-size:30px">Источник: <?php echo esc_html( $t->name ); ?></h1>
	<?php if ( $t->description ) : ?><p class="muted" style="max-width:70ch;margin-top:10px"><?php echo wp_kses_post( $t->description ); ?></p><?php endif; ?>
	<p class="small muted">Режим использования: адаптация по мотивам. Проект не аффилирован с автором и правообладателем. <a href="<?php echo esc_url( home_url( '/method/' ) ); ?>">Наш стандарт атрибуции</a>.</p>
	<div class="grid g3" style="margin-top:24px"><?php while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'template-parts/card-situation' ); endwhile; wp_reset_postdata(); ?></div>
</div>
<?php get_footer(); ?>
