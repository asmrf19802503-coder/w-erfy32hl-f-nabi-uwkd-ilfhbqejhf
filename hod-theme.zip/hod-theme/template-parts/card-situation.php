<?php
/** Карточка ситуации в сетке. Ожидает $post в глобальной области или передачу через 'card'. */
defined( 'ABSPATH' ) || exit;
$p    = isset( $args['post'] ) ? $args['post'] : get_post();
$id   = $p->ID;
$code = hod_meta( $id, 'code', $p->post_name );
$col  = hod_series_color( $id );
$pro  = 'pro' === hod_meta( $id, 'access_level', 'free' );
$q    = hod_meta( $id, 'counterpart_line', get_the_title( $id ) );
$fw   = hod_meta( $id, 'framework_name_own' );
?>
<a class="card scard" href="<?php the_permalink( $id ); ?>" style="text-decoration:none;color:inherit">
	<div class="stripe" style="background:<?php echo esc_attr( $col ); ?>"></div>
	<?php if ( has_post_thumbnail( $id ) ) : ?>
		<div class="thumb"><img src="<?php echo esc_url( get_the_post_thumbnail_url( $id, 'hod-card' ) ); ?>" alt="" loading="lazy" width="640" height="360">
			<div class="codetag"><?php echo esc_html( $code ); ?></div>
			<div class="play"><svg width="16" height="16" viewBox="0 0 24 24" fill="#101418" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></div>
			<div class="dur"><?php echo esc_html( hod_duration( $id ) ); ?></div>
		</div>
	<?php else : ?>
		<div class="thumb" style="background:<?php echo esc_attr( $col ); ?>14">
			<div class="codetag"><?php echo esc_html( $code ); ?></div>
			<div class="play"><svg width="16" height="16" viewBox="0 0 24 24" fill="#101418" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></div>
			<div class="dur"><?php echo esc_html( hod_duration( $id ) ); ?></div>
			<div style="position:absolute;left:12px;right:12px;bottom:12px;font-weight:700;font-size:15px;line-height:1.25;color:<?php echo esc_attr( $col ); ?>"><?php echo esc_html( wp_trim_words( $q, 8, '…' ) ); ?></div>
		</div>
	<?php endif; ?>
	<div class="body">
		<div class="meta"><span class="badge b-code"><?php echo esc_html( $code ); ?></span><span class="seriesdot" style="background:<?php echo esc_attr( $col ); ?>"></span></div>
		<div class="q">«<?php echo esc_html( wp_trim_words( $q, 12, '…' ) ); ?>»</div>
		<?php if ( $fw ) : ?><div class="small muted">Приём: <?php echo esc_html( $fw ); ?></div><?php endif; ?>
	</div>
	<div class="foot">
		<span class="badge <?php echo $pro ? 'b-pro' : 'b-free'; ?>"><?php echo $pro ? 'Pro' : 'Free'; ?></span>
		<span class="mono"><?php echo esc_html( hod_duration( $id ) ); ?></span>
	</div>
</a>
