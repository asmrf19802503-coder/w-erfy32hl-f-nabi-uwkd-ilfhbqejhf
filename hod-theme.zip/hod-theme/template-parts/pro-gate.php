<?php
/**
 * Pro-блок карточки: ветки, тренажёр-развилки, готовые формулировки, чек-лист, пак инструментов.
 * Гостю содержимое на сервере НЕ отдаётся: только счётчики и первые 90 знаков веток в размытом тизере.
 */
defined( 'ABSPATH' ) || exit;

$id = isset( $args['id'] ) ? (int) $args['id'] : get_the_ID();
$g  = function ( $k ) use ( $id ) {
	return function_exists( 'get_field' ) ? (string) get_field( $k, $id ) : (string) hod_meta( $id, $k );
};

$c = hod_pro_counts( $id );
$raw = $g( 'branches' );

// ---------------------------------------------------------------------------
// Доступ Pro есть: отдаём всё
// ---------------------------------------------------------------------------
if ( hod_is_pro() ) {
	$br = hod_branches( $raw );
	if ( ! $br && ! $c['drills'] && ! $c['templates'] && ! $c['checklist'] ) { return; }

	echo '<div class="card pad pro-open">';

	if ( $br ) {
		echo '<div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Развилки диалога</div><ol class="small" style="padding-left:20px">';
		foreach ( $br as $i => $b ) {
			echo '<li style="margin-bottom:10px"><b>' . esc_html( $b['if'] ) . '</b>';
			if ( $b['then'] ) { echo ' - ' . esc_html( $b['then'] ); }
			echo '</li>';
		}
		echo '</ol>';
	}

	$drills = hod_drills( $g( 'pro_drill' ) );
	if ( $drills ) {
		echo '<div class="hr" style="margin:18px 0"></div>';
		echo '<div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Тренажёр: выбери ответ</div>';
		foreach ( $drills as $i => $d ) {
			echo '<details class="hod-drill" style="margin-bottom:10px;border:1px solid var(--line);border-radius:10px;padding:10px 12px">';
			echo '<summary style="cursor:pointer;font-weight:600;font-size:14px">' . esc_html( $d['case'] ) . '</summary>';
			echo '<div class="small" style="margin-top:10px">';
			if ( $d['right'] ) { echo '<div class="good-say" style="padding:8px 10px;border-radius:8px;margin-bottom:6px"><b>Верно:</b> ' . esc_html( preg_replace( '/^Верно:\s*/u', '', $d['right'] ) ) . '</div>'; }
			if ( $d['wrong'] ) { echo '<div class="bad-say" style="padding:8px 10px;border-radius:8px;margin-bottom:6px"><b>Неверно:</b> ' . esc_html( preg_replace( '/^Неверно:\s*/u', '', $d['wrong'] ) ) . '</div>'; }
			if ( $d['why'] ) { echo '<div class="muted"><b>Почему:</b> ' . esc_html( preg_replace( '/^Почему:\s*/u', '', $d['why'] ) ) . '</div>'; }
			echo '</div></details>';
		}
	}

	$tpl = hod_lines( $g( 'pro_templates' ) );
	if ( $tpl ) {
		echo '<div class="hr" style="margin:18px 0"></div>';
		echo '<div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Готовые формулировки</div>';
		foreach ( $tpl as $t ) {
			echo '<div class="small" style="background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:10px 12px;margin-bottom:8px;white-space:pre-wrap">' . esc_html( $t ) . '</div>';
		}
	}

	$cl = hod_lines( $g( 'pro_checklist' ) );
	if ( $cl ) {
		echo '<div class="hr" style="margin:18px 0"></div>';
		echo '<div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Чек-лист подготовки</div><ul class="hod-check small">';
		foreach ( $cl as $item ) {
			echo '<li style="margin-bottom:6px"><span class="chkbox" aria-hidden="true"></span>' . esc_html( $item ) . '</li>';
		}
		echo '</ul>';
	}

	if ( $c['pack'] ) {
		echo '<div class="hr" style="margin:18px 0"></div>';
		echo '<div class="small"><span class="badge b-pro">Пак</span> ' . esc_html( $c['pack'] ) . '</div>';
	}

	$files = array_values( array_filter( array_map( 'trim', explode( ',', $g( 'pro_files' ) ) ) ) );
	if ( $files ) {
		echo '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">';
		foreach ( $files as $i => $f ) {
			echo '<a class="btn btn-o btn-s" href="' . esc_url( add_query_arg( 'hod_file', $i, get_permalink( $id ) ) ) . '">'
				. esc_html( basename( (string) wp_parse_url( $f, PHP_URL_PATH ) ) ) . '</a>';
		}
		echo '</div>';
	}

	echo '<div class="xs muted" style="margin-top:14px">Pro-материалы: ' . (int) $c['chars'] . ' знаков. Экспорт карточки: '
		. '<a href="' . esc_url( add_query_arg( 'hod_export', 'md', get_permalink( $id ) ) ) . '">Markdown</a> · '
		. '<a href="' . esc_url( add_query_arg( 'hod_export', 'txt', get_permalink( $id ) ) ) . '">TXT для Notion</a></div>';
	echo '</div>';
	return;
}

// ---------------------------------------------------------------------------
// Гостя: тизер без содержимого
// ---------------------------------------------------------------------------
$preview = mb_substr( preg_replace( '/\s+/', ' ', $raw ), 0, 90 );
?>
<div class="card progate progate-tall">
	<div class="progate-blur blurred" aria-hidden="true">
		<div class="small"><?php echo esc_html( $preview ); ?>...</div>
		<div class="small" style="margin-top:8px"><?php echo esc_html( mb_substr( preg_replace( '/\s+/', ' ', $raw ), 90, 90 ) ); ?>...</div>
		<div class="small" style="margin-top:8px"><?php echo esc_html( mb_substr( preg_replace( '/\s+/', ' ', (string) $g( 'pro_drill' ) ), 0, 90 ) ); ?>...</div>
	</div>
	<div class="pro-panel">
		<span class="badge b-pro">Только в Pro</span>
		<b style="font-size:18px"><?php echo (int) $c['branches']; ?> развилки · <?php echo (int) $c['drills']; ?> тренажёра · <?php echo (int) $c['templates']; ?> шаблона</b>
		<span class="small muted" style="max-width:44ch">Что говорить, если ответят иначе: отказ, отсрочка, давление, переход к конкуренту, выход на другого собеседника. Плюс тренажёр «выбери ответ», готовые формулировки и чек-лист подготовки.</span>
		<ul class="small" style="margin:10px 0 12px;padding-left:18px">
			<li><?php echo (int) $c['branches']; ?> ветки развития диалога</li>
			<li><?php echo (int) $c['drills']; ?> развилки тренажёра с разбором «верно / неверно / почему»</li>
			<li><?php echo (int) $c['templates']; ?> готовые формулировки: письма и фразы</li>
			<li><?php echo (int) $c['checklist']; ?> пунктов чек-листа подготовки</li>
			<?php if ( $c['pack'] ) : ?><li>Пак инструментов: <?php echo esc_html( $c['pack'] ); ?></li><?php endif; ?>
		</ul>
		<a class="btn btn-a btn-s" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Открыть за 390 руб./мес</a>
		<a class="xs" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>" style="text-decoration:underline">Что входит в Pro</a>
	</div>
</div>
