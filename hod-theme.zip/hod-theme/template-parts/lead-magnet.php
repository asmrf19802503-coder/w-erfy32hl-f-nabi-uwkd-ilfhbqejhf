<?php defined( 'ABSPATH' ) || exit; ?>
<section class="blk" style="background:var(--ink);color:#fff">
	<div class="wrap" style="display:grid;grid-template-columns:1.2fr 1fr;gap:34px;align-items:center">
		<div>
			<h2 style="color:#fff;font-size:30px"><?php echo esc_html( isset( $args['title'] ) ? $args['title'] : '12 ситуаций бесплатно на почту' ); ?></h2>
			<p style="color:#B7C0CB;margin-top:12px;max-width:52ch">Первый контакт, цена и скидка, позиционирование - PDF и Notion-версия. Дальше одно письмо в неделю: пять новых ситуаций и один разбор ошибки.</p>
		</div>
		<form class="card pad hod-form" data-hod-form="subscribe" style="background:#171D25;border-color:#2A333D" novalidate>
			<label style="color:#93A0B0">Имя</label>
			<input name="name" type="text" style="background:#10151B;border-color:#2E3844;color:#fff" placeholder="Как к вам обращаться">
			<label style="color:#93A0B0">Email</label>
			<input name="email" type="email" required style="background:#10151B;border-color:#2E3844;color:#fff" placeholder="you@company.ru">
			<label style="color:#93A0B0">Ваша роль</label>
			<select name="role" style="background:#10151B;border-color:#2E3844;color:#fff">
				<option>SDR / специалист по продажам</option><option>AE / менеджер по продажам</option>
				<option>Руководитель отдела продаж</option><option>Маркетолог / CMO</option>
				<option>Фаундер / директор</option><option>HR / руководитель команды</option>
			</select>
			<label style="color:#93A0B0;display:flex;gap:8px;text-transform:none;letter-spacing:0;font-weight:500;font-size:12.5px;margin-top:12px">
				<input type="checkbox" name="consent" value="1" required style="width:auto"> Согласен на обработку персональных данных и получение писем
			</label>
			<button class="btn btn-a" style="width:100%;margin-top:12px">Забрать 12 ситуаций</button>
			<div class="form-msg" hidden></div>
		</form>
	</div>
</section>
