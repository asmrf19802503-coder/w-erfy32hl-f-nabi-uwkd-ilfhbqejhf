<?php defined( 'ABSPATH' ) || exit;
$id  = isset( $args['id'] ) ? $args['id'] : get_the_ID();
$raw = function_exists( 'get_field' ) ? (string) get_field( 'dialogue_turns', $id ) : (string) hod_meta( $id, 'dialogue_turns' );
$dlg = hod_dialogue( $raw );
if ( ! $dlg ) { return; }
?>
<div class="dlg2">
<?php foreach ( $dlg as $t ) :
	$is_you = preg_match( '/^(вы|продавец|руководитель|специалист|маркетолог|фаундер|hr)/iu', (string) $t['who'] );
	?>
	<div class="turn2<?php echo $is_you ? ' you' : ''; ?>">
		<span class="who2"><?php echo esc_html( $t['who'] ); ?></span>
		<div class="say2"><?php echo esc_html( $t['say'] ); ?></div>
	</div>
<?php endforeach; ?>
</div>
