<?php
/** Ленивый видео-фасад: iframe грузится только по клику. Ожидает $args['id']. */
defined( 'ABSPATH' ) || exit;
$id   = isset( $args['id'] ) ? $args['id'] : get_the_ID();
$url  = hod_meta( $id, 'video_url' );
$code = hod_meta( $id, 'code' );
$dur  = hod_duration( $id );
$hook = hod_meta( $id, 'hook_0_2s' );
if ( ! $url ) {
	echo '<div class="thumb" style="border-radius:var(--r3);background:linear-gradient(135deg,#1B2A4A,#0F1620)"><div class="codetag">' . esc_html( $code ) . '</div><div class="dur">' . esc_html( $dur ) . '</div><div style="position:absolute;left:16px;bottom:14px;color:#fff;font-weight:750;font-size:19px;max-width:80%">' . esc_html( $hook ) . '</div></div>';
	return;
}
$embed = '';
if ( preg_match( '#youtu\.?be#i', $url ) ) {
	$m = array();
	if ( preg_match( '#(?:v=|youtu\.be/)([A-Za-z0-9_\-]{6,})#', $url, $m ) ) { $embed = 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?rel=0&modestbranding=1'; }
} elseif ( preg_match( '#vk\.com/video#i', $url ) ) { $embed = $url; }
?>
<div class="videofacade" data-embed="<?php echo esc_attr( $embed ); ?>" role="button" tabindex="0" aria-label="Смотреть видео <?php echo esc_attr( $code ); ?>">
	<?php if ( has_post_thumbnail( $id ) ) : ?><img src="<?php echo esc_url( get_the_post_thumbnail_url( $id, 'large' ) ); ?>" alt="" loading="lazy"><?php endif; ?>
	<div class="play"><svg width="22" height="22" viewBox="0 0 24 24" fill="#101418" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></div>
	<div class="dur"><?php echo esc_html( $dur ); ?></div>
	<div class="codetag" style="position:absolute;left:12px;top:12px;background:rgba(255,255,255,.95);padding:3px 8px;border-radius:5px;font-family:var(--mono);font-size:11px;font-weight:700"><?php echo esc_html( $code ); ?></div>
</div>
