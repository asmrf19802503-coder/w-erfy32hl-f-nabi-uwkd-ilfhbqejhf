<?php
/**
 * Гейт всей карточки для платных категорий (access_level = pro): PM, паки, Pro-серии.
 * Видео и блоки «Ситуация» и «Типичная ошибка» остаются бесплатными - это витрина.
 * Приём, диалог, ветки, тренажёр, шаблоны, результат и метрики отдаются только с доступом Pro.
 */
defined( 'ABSPATH' ) || exit;

$id   = isset( $args['id'] ) ? (int) $args['id'] : get_the_ID();
$code = isset( $args['code'] ) ? $args['code'] : hod_meta( $id, 'code', '' );
$c    = hod_pro_counts( $id );
$ser  = hod_series( $id );
?>
<div class="card progate progate-static" style="margin-top:26px">
	<div class="pro-panel" style="max-width:none">
		<span class="badge b-pro">Карточка категории Pro</span>
		<b style="font-size:20px;display:block;margin:10px 0 6px">Дальше - платная часть <?php echo esc_html( $code ); ?></b>
		<p class="small muted" style="max-width:64ch;margin-bottom:12px">
			Видео, ситуация и типичная ошибка открыты всегда: это витрина и способ понять, ваша ли это история.
			Приём, полный диалог, развилки, тренажёр, шаблоны и метрики - в Pro.
		</p>
		<ul class="small" style="margin:0 0 14px;padding-left:18px;columns:2;column-gap:26px">
			<li>Приём и почему он работает</li>
			<li>Диалог по репликам</li>
			<li><?php echo (int) $c['branches']; ?> развилки: если ответят иначе</li>
			<li><?php echo (int) $c['drills']; ?> тренажёра «выбери ответ»</li>
			<li><?php echo (int) $c['templates']; ?> готовые формулировки</li>
			<li>Чек-лист подготовки (<?php echo (int) $c['checklist']; ?> п.)</li>
			<li>Результат, следующий шаг, метрики</li>
			<li>Правовая рамка ТК РФ<?php if ( $ser ) : ?> и серия «<?php echo esc_html( $ser->name ); ?>»<?php endif; ?></li>
		</ul>
		<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
			<a class="btn btn-a" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Открыть Pro - 390 ₽/мес</a>
			<a class="btn btn-o" href="<?php echo esc_url( home_url( '/pro/#packs' ) ); ?>">Купить пак отдельно</a>
			<span class="xs muted">Первый месяц 99 ₽ · отмена в один клик · возврат 14 дней</span>
		</div>
	</div>
</div>

<div class="note" style="margin-top:16px">
	<b>Почему эта категория платная.</b> Карточки про управление людьми требуют проверки правовых норм (ТК РФ),
	кадровых документов и разбора записей. Это работа, которую нельзя делать «на коленке», поэтому она не бесплатна.
	Бесплатными остаются 2 карточки в каждой серии - чтобы формат можно было проверить до оплаты.
</div>
