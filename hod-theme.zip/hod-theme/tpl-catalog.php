<?php /* Template Name: Каталог (альтернатива архиву) */ get_template_part( 'archive', 'situation' ); ?>
