<?php /* Template Name: Категория Управление персоналом */ defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap" style="padding-top:30px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px"><span class="seriesdot dot-pm" style="width:14px;height:14px;border-radius:4px"></span><span class="mono small muted">Домен PM · People Management · только в Pro</span></div>
	<h1 style="font-size:34px;max-width:22ch">Управление персоналом: ситуации, которых нет в учебниках</h1>
	<p class="lead muted" style="font-size:17px;margin-top:14px;max-width:70ch">Подбор, адаптация, обучение, мотивация, результативность, сложные разговоры и компенсации. Тот же формат, что и в продажах: дословная реплика, типичная ошибка руководителя, приём, диалог, ветки, результат. Плюс обязательная правовая рамка ТК РФ.</p>
	<div style="display:flex;gap:10px;flex-wrap:wrap;margin:20px 0 26px">
		<a class="btn btn-a" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Открыть в Pro - 390 ₽/мес</a>
		<a class="btn btn-o" href="#free-pm">Смотреть 2 бесплатные ситуации</a>
	</div>
	<h2 style="font-size:21px;margin-bottom:14px">7 серий категории</h2>
	<div class="grid g3">
	<?php
	$series = array(
		array( 'RC', 'Найм и отказ кандидату', '«Хочу на 30% больше» · сильный кандидат отказался · внутренняя ротация · как отказать и не сжечь рынок', '8-10' ),
		array( 'ON', 'Первые 90 дней', 'Новичок не справляется в первый месяц · наставник не тянет · как сказать, что испытательный срок не пройден', '6-8' ),
		array( 'LR', 'Обучение и развитие', '«Обучим - и он уйдёт» · нет времени на обучение · как измерить результат обучения · развитие без повышения', '6-8' ),
		array( 'MT', 'Мотивация и деньги', 'Просит прибавку, а бюджета нет · премия перестала работать · выгорел сильный сотрудник · нематериальная мотивация без пафоса', '10-12' ),
		array( 'PF', 'Обратная связь и результат', 'Старается, но план не выполняет · жёсткая обратная связь без потери человека · токсичная звезда · цели, которые выполняют', '8-10' ),
		array( 'MG', 'Руководство и сложные разговоры', 'Принял бывших коллег · «быстрее сделать самому» · конфликт двух сильных · разговор об увольнении · удалённая команда', '10-12' ),
		array( 'CM', 'Зарплаты, вилки, пересмотр', 'Все просят пересмотр · вилка против рынка · прозрачность зарплат · как объяснить разницу внутри команды · индексация', '6-8' ),
		array( 'LAW', 'Правовая рамка руководителя', 'Дисциплинарное взыскание (ст. 192-193 ТК РФ) · испытательный срок (ст. 70-71) · изменение условий (ст. 72, 74) · документы при увольнении · персональные данные', '6-8' ),
	);
	foreach ( $series as $s ) {
		echo '<div class="card scard"><div class="stripe st-pm"></div><div class="body"><div class="meta">' . esc_html( $s[0] ) . ' · ' . esc_html( $s[1] ) . '</div><div class="q">' . esc_html( $s[1] ) . '</div><div class="small muted">' . esc_html( $s[2] ) . '</div></div><div class="foot"><span class="badge b-pro">Pro</span><span>' . esc_html( $s[3] ) . ' ситуаций</span></div></div>';
	}
	?>
	<div class="card scard" style="border-style:dashed"><div class="body"><div class="meta">+ вы</div><div class="q">Ваши ситуации</div><div class="small muted">Присылайте реплику сотрудника или кандидата - разбираем в ближайшем выпуске. Это главный источник карточек категории.</div></div><div class="foot"><span class="badge b-free">Бесплатно</span><span><a href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать →</a></span></div></div>
	</div>
	<div class="grid g2" style="margin-top:28px">
		<div class="callout"><b>Почему категория платная.</b> Аудитория другая - руководители и HR, у них есть бюджет и срочность. Конкуренция ниже, чем в продажах. Плюс выше правовая чувствительность: каждую карточку нужно проверять на соответствие ТК РФ.</div>
		<div class="callout warn"><b>Правовая рамка обязательна.</b> В каждой карточке PM: ссылка на норму ТК РФ, предупреждение «не является юридической консультацией» и полное обезличивание примеров (152-ФЗ). Мы не даём советов по обходу закона: серые схемы оплаты, подлог кадровых документов, давление при увольнении - вне библиотеки.</div>
	</div>
	<h2 id="free-pm" style="font-size:21px;margin:32px 0 12px">Бесплатные ситуации категории</h2>
	<div class="grid g3"><?php
	$q = new WP_Query( array( 'post_type' => 'situation', 'posts_per_page' => 3, 'tax_query' => array( array( 'taxonomy' => 'domain', 'field' => 'slug', 'terms' => array( 'people' ) ) ), 'meta_query' => array( array( 'key' => 'access_level', 'value' => 'free' ) ), 'no_found_rows' => true ) );
	while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'template-parts/card-situation' ); endwhile; wp_reset_postdata();
	if ( ! $q->post_count ) { echo '<div class="note" style="grid-column:1/-1">Бесплатных карточек PM пока нет. Отметьте две карточки как <code>access_level = free</code> - они появятся здесь.</div>'; }
	?></div>
	<p class="xs muted" style="margin-top:10px">Режим использования - адаптация по мотивам. Проект не аффилирован с авторами и правообладателями. <a href="<?php echo esc_url( home_url( '/method/' ) ); ?>">Наш стандарт атрибуции</a>.</p>
</div>
<?php get_footer(); ?>
