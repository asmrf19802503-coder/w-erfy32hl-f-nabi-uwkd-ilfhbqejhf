<?php defined( 'ABSPATH' ) || exit; get_header();
$t = get_queried_object();
$q = new WP_Query( array( 'post_type' => 'situation', 'posts_per_page' => 24, 'tax_query' => array( array( 'taxonomy' => 'objection', 'field' => 'term_id', 'terms' => $t->term_id ) ), 'no_found_rows' => true ) );
$first = $q->have_posts() ? $q->posts[0] : null;
add_filter( 'hod_faq_schema', function ( $faq ) use ( $t ) {
	$faq[] = array( 'q' => 'Что ответить, если говорят «' . $t->name . '»?', 'a' => 'Сначала понять причину, а не спорить: в библиотеке есть карточка с дословной репликой, типичной ошибкой, приёмом и готовым диалогом.' );
	return $faq;
} );
?>
<div class="wrap" style="padding-top:28px;padding-bottom:48px;max-width:900px">
	<?php hod_breadcrumbs(); ?>
	<h1 style="font-size:34px;max-width:22ch">Что ответить на «<?php echo esc_html( $t->name ); ?>»</h1>
	<?php if ( $t->description ) : ?><p class="lead muted" style="font-size:17px;margin-top:12px"><?php echo wp_kses_post( $t->description ); ?></p><?php endif; ?>
	<?php if ( $first ) : $fid = $first->ID; ?>
	<div class="grid g3" style="margin:24px 0">
		<div class="card pad"><div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Ошибка</div><b><?php echo esc_html( wp_trim_words( hod_meta( $fid, 'common_mistake' ), 12, '…' ) ); ?></b></div>
		<div class="card pad"><div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Приём</div><b><?php echo esc_html( hod_meta( $fid, 'framework_name_own' ) ); ?></b><p class="small muted" style="margin:6px 0 0"><?php echo esc_html( wp_trim_words( hod_meta( $fid, 'framework_origin' ), 14, '…' ) ); ?></p></div>
		<div class="card pad"><div class="xs muted" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Следующий шаг</div><b><?php echo esc_html( wp_trim_words( hod_meta( $fid, 'next_step' ), 12, '…' ) ); ?></b></div>
	</div>
	<?php get_template_part( 'template-parts/videofacade', null, array( 'id' => $fid ) ); ?>
	<?php endif; ?>

	<h2 style="font-size:21px;margin:30px 0 12px">Все ситуации по этому возражению</h2>
	<div class="grid g2"><?php while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'template-parts/card-situation' ); endwhile; wp_reset_postdata(); ?></div>

	<?php if ( $first ) : $ds = hod_lines( hod_meta( $first->ID, 'dont_say' ) ); if ( $ds ) : ?>
		<h2 style="font-size:21px;margin:30px 0 12px">Чего говорить нельзя</h2>
		<div class="bad-say"><?php foreach ( $ds as $d ) { echo '«' . esc_html( $d ) . '» · '; } ?></div>
	<?php endif; endif; ?>

	<h2 style="font-size:21px;margin:30px 0 12px">Связанные возражения</h2>
	<div style="display:flex;gap:8px;flex-wrap:wrap">
		<?php $rel = get_terms( array( 'taxonomy' => 'objection', 'hide_empty' => true, 'number' => 8, 'exclude' => array( $t->term_id ) ) );
		if ( $rel && ! is_wp_error( $rel ) ) { foreach ( $rel as $r ) { echo '<a class="chip" href="' . esc_url( get_term_link( $r ) ) . '">' . esc_html( $r->name ) . '</a>'; } } ?>
	</div>

	<div class="card pad" style="margin-top:30px;background:var(--mist)">
		<h3 style="margin-bottom:10px">Частые вопросы</h3>
		<details class="hod-faq"><summary>Что ответить, если говорят «<?php echo esc_html( $t->name ); ?>»?</summary><p class="small muted" style="margin-top:8px">Сначала выяснить причину, а не спорить с формулировкой. В карточке выше - дословная реплика, типичная ошибка, приём и готовый диалог.</p></details>
		<details class="hod-faq"><summary>Это работает в любой отрасли?</summary><p class="small muted" style="margin-top:8px">Приём универсален, а формулировки - нет. В карточке указан блок «Не работает, когда»: проверьте его до применения.</p></details>
		<details class="hod-faq"><summary>Где взять шаблоны и ветки диалога?</summary><p class="small muted" style="margin-top:8px">В Pro-версии карточки: 2-5 веток развития, шаблоны писем и расчётов, экспорт в PDF и Notion.</p></details>
	</div>
	<div style="margin-top:26px"><?php get_template_part( 'template-parts/lead-magnet', null, array( 'title' => 'Все ситуации по возражению «' . $t->name . '» - на почту' ) ); ?></div>
</div>
<?php get_footer(); ?>
