</main>
<footer class="ft">
	<div class="wrap">
		<div class="ft-grid">
			<div>
				<div class="logo" style="color:#fff;margin-bottom:12px">
					<svg width="28" height="28" viewBox="0 0 32 32" fill="none" aria-hidden="true"><rect width="32" height="32" rx="8" fill="#1B4DFF"/><path d="M9 21.5L14.5 16L9 10.5" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="21" cy="16" r="2.6" fill="#FF5A1F"/></svg>
					<span style="color:#fff"><?php bloginfo( 'name' ); ?><small style="color:#7C8794">библиотека ситуаций</small></span>
				</div>
				<p class="small" style="color:#8E98A4;max-width:38ch">Одна ситуация - одна ошибка - один приём - один следующий шаг. Библиотека пополняется каждую неделю.</p>
			</div>
			<div><h4>Библиотека</h4>
				<a href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Каталог</a><br>
				<a href="<?php echo esc_url( home_url( '/series/' ) ); ?>">Серии</a><br>
				<a href="<?php echo esc_url( home_url( '/objections/' ) ); ?>">Возражения</a><br>
				<a href="<?php echo esc_url( home_url( '/pm/' ) ); ?>">Управление персоналом</a>
			</div>
			<div><h4>О проекте</h4>
				<a href="<?php echo esc_url( home_url( '/method/' ) ); ?>">Метод и источники</a><br>
				<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>">Реестр источников</a><br>
				<a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">Об авторе</a><br>
				<a href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a>
			</div>
			<div><h4>Доступ</h4>
				<a href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">Тарифы Pro и Team</a><br>
				<a href="<?php echo esc_url( home_url( '/pro/#packs' ) ); ?>">Наборы карточек</a><br>
				<a href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Поддержка</a><br>
				<span class="small" style="color:#8E98A4">Telegram · YouTube · VK · Rutube · Дзен</span>
			</div>
		</div>
		<div class="ft-bot">
			<span>© <?php echo esc_html( date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. Тексты сценариев, структура карточек и классификация ситуаций охраняются авторским правом. Образовательный контент, не является консультацией.</span>
			<span>
				<a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>">Условия</a> ·
				<a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>">Конфиденциальность</a> ·
				<a href="<?php echo esc_url( home_url( '/disclaimer/' ) ); ?>">Дисклеймер</a>
			</span>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
