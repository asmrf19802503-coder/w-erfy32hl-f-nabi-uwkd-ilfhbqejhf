<?php /* Template Name: Реестр источников */ defined( 'ABSPATH' ) || exit; get_header();
$q = new WP_Query( array( 'post_type' => 'source', 'posts_per_page' => 100, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true ) ); ?>
<div class="wrap article" style="padding-top:30px;padding-bottom:48px;max-width:980px">
	<?php hod_breadcrumbs(); ?>
	<h1>Реестр источников библиотеки</h1>
	<p class="lead muted" style="font-size:17px;margin-top:12px">Мы указываем источник идеи, а не воспроизводим текст: цитирование отсутствует либо ограничено объёмом, оправданным целью. Первоисточники - в лицензионных копиях и подписках. Купить книгу можно по ссылкам в таблице; часть ссылок партнёрская.</p>
	<?php if ( $q->have_posts() ) : ?>
	<table class="tbl" style="margin-top:22px"><thead><tr><th>Источник</th><th style="width:170px">Автор, год</th><th style="width:120px">Тип</th><th style="width:150px">Легально</th><th style="width:170px">Где купить</th></tr></thead><tbody>
	<?php while ( $q->have_posts() ) : $q->the_post(); $id = get_the_ID();
		$types = array( 'book' => 'Книга', 'research' => 'Исследование', 'interview' => 'Интервью', 'regulation' => 'Норма', 'internal_case' => 'Собственный кейс' );
		$tt = hod_meta( $id, 'source_type' );
		$links = hod_lines( hod_meta( $id, 'buy_links' ) );
		?>
		<tr><td><b><?php the_title(); ?></b><div class="xs muted"><?php echo esc_html( hod_meta( $id, 'source_edition' ) ); ?></div></td>
		<td class="small"><?php echo esc_html( hod_meta( $id, 'source_author2' ) ); ?><?php if ( hod_meta( $id, 'source_year2' ) ) : ?>, <?php echo esc_html( hod_meta( $id, 'source_year2' ) ); ?><?php endif; ?></td>
		<td class="small"><?php echo esc_html( isset( $types[ $tt ] ) ? $types[ $tt ] : $tt ); ?></td>
		<td class="small"><?php echo hod_meta( $id, 'legally_obtained' ) ? '<span style="color:#046A4A;font-weight:700">да</span>' : '<span style="color:#B33C0C">проверяется</span>'; ?></td>
		<td class="small"><?php foreach ( array_slice( $links, 0, 3 ) as $l ) { $p = preg_split( '/\s+-\s+|\s+-\s+/', $l, 2 ); if ( isset( $p[1] ) ) { echo '<a href="' . esc_url( $p[1] ) . '" rel="nofollow sponsored noopener" target="_blank">' . esc_html( $p[0] ) . '</a><br>'; } else { echo esc_html( $l ) . '<br>'; } } ?></td></tr>
	<?php endwhile; wp_reset_postdata(); ?>
	</tbody></table>
	<?php else : ?>
		<div class="note">Источники ещё не заведены. Создайте записи в разделе <b>Источники</b> (CPT <code>source</code>) - таблица заполнится автоматически.</div>
	<?php endif; ?>
	<p class="xs muted" style="margin-top:18px">Издания, перешедшие в общественное достояние (например, Claude Hopkins, Scientific Advertising, 1923), используются свободно. Статус товарных знаков методологий проверяется отдельно по каждой юрисдикции; дата последней проверки указывается в карточке источника.</p>
</div>
<?php get_footer(); ?>
