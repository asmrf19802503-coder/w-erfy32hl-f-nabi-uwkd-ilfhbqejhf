<?php
/**
 * ХОД - дочерняя тема. Точка входа.
 */
defined( 'ABSPATH' ) || exit;

define( 'HOD_VER', '1.0.0' );
define( 'HOD_DIR', get_stylesheet_directory() );
define( 'HOD_URI', get_stylesheet_directory_uri() );

foreach ( array( 'setup', 'cpt', 'helpers', 'fields', 'access', 'account', 'export', 'seo', 'importer' ) as $f ) {
	require_once HOD_DIR . '/inc/' . $f . '.php';
}

/** Заметка, если не активен ACF (поля карточек без него не работают). */
add_action( 'admin_notices', function () {
	if ( ! class_exists( 'ACF' ) && ! function_exists( 'get_field' ) ) {
		echo '<div class="notice notice-error"><p><strong>ХОД:</strong> не активен плагин Advanced Custom Fields (бесплатной версии достаточно). Без него поля карточек не работают. <a href="' . esc_url( admin_url( 'plugin-install.php?s=advanced+custom+fields&tab=search&type=term' ) ) . '">Установить</a></p></div>';
	}
} );
