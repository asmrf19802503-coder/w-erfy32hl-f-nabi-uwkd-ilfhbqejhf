/* ХОД - минимум JS: формы, видео-фасад, фильтры. Без зависимостей. */
(function () {
  'use strict';

  /* 1. Видео-фасад: iframe грузится только по клику */
  document.addEventListener('click', function (e) {
    var f = e.target.closest('.videofacade');
    if (!f || !f.dataset.embed || f.dataset.loaded) { return; }
    var iframe = document.createElement('iframe');
    iframe.src = f.dataset.embed + (f.dataset.embed.indexOf('?') > -1 ? '&' : '?') + 'autoplay=1';
    iframe.title = 'Видео ситуации';
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    iframe.allowFullscreen = true;
    iframe.loading = 'lazy';
    f.innerHTML = '';
    f.appendChild(iframe);
    f.dataset.loaded = '1';
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ' ') { return; }
    var f = e.target.closest && e.target.closest('.videofacade');
    if (f) { e.preventDefault(); f.click(); }
  });

  /* 2. Формы через admin-ajax */
  document.addEventListener('submit', function (e) {
    var form = e.target.closest('form[data-hod-form]');
    if (!form) { return; }
    e.preventDefault();
    var msg = form.querySelector('.form-msg');
    var bad = false;
    form.querySelectorAll('[required]').forEach(function (i) {
      var ok = i.type === 'checkbox' ? i.checked : String(i.value).trim() !== '';
      i.classList.toggle('err', !ok);
      if (!ok) { bad = true; }
    });
    if (bad) {
      if (msg) { msg.hidden = false; msg.className = 'form-msg bad'; msg.textContent = 'Заполните обязательные поля и дайте согласие на обработку данных.'; }
      return;
    }
    var fd = new FormData(form);
    fd.append('action', 'hod_form');
    fd.append('nonce', (window.HOD && HOD.nonce) || '');
    fd.append('ftype', form.dataset.hodForm);
    if (msg) { msg.hidden = false; msg.className = 'form-msg'; msg.textContent = 'Отправляем…'; }
    fetch((window.HOD && HOD.ajax) || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (!msg) { return; }
        msg.hidden = false;
        msg.className = 'form-msg ' + (r && r.success ? 'ok' : 'bad');
        msg.textContent = (r && r.data && r.data.msg) ? r.data.msg : 'Что-то пошло не так. Попробуйте ещё раз.';
        if (r && r.success) {
          form.querySelectorAll('input, textarea').forEach(function (i) { if (i.type !== 'submit') { i.value = ''; } });
          if (window.dataLayer) { window.dataLayer.push({ event: 'hod_form', ftype: form.dataset.hodForm }); }
        }
      })
      .catch(function () { if (msg) { msg.className = 'form-msg bad'; msg.textContent = 'Ошибка сети. Проверьте соединение.'; } });
  });

  /* 3. Фильтры каталога: автоотправка при изменении */
  var rail = document.querySelector('.rail form');
  if (rail) {
    rail.querySelectorAll('input[type=checkbox]').forEach(function (c) {
      c.addEventListener('change', function () { rail.submit(); });
    });
  }

  /* 4. Плавная прокрутка по оглавлению карточки */
  document.querySelectorAll('.rail ol a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var i = Array.prototype.indexOf.call(a.parentNode.children, a.parentNode);
      var heads = document.querySelectorAll('.article h2');
      if (heads[i]) { e.preventDefault(); heads[i].scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();

/* 5. Сохранённые карточки и операции с доступом (личный кабинет Pro) */
(function () {
  if (!window.HOD || !window.HOD.ajax) { return; }

  function post(data, cb) {
    var body = new URLSearchParams();
    body.append('nonce', HOD.nonce);
    Object.keys(data).forEach(function (k) { if (data[k] !== null && data[k] !== undefined) { body.append(k, data[k]); } });
    fetch(HOD.ajax, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (r) { return r.json(); })
      .then(cb)
      .catch(function () { cb({ success: false, data: { msg: 'Ошибка сети. Проверьте соединение.' } }); });
  }

  document.querySelectorAll('[data-hod-save]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var msg = document.querySelector('.save-msg');
      btn.disabled = true;
      post({ action: 'hod_save', id: btn.getAttribute('data-hod-save') }, function (r) {
        btn.disabled = false;
        if (r && r.success) {
          var on = !!r.data.saved;
          btn.classList.toggle('on', on);
          btn.setAttribute('aria-pressed', on ? 'true' : 'false');
          btn.innerHTML = '<span class="ico" aria-hidden="true">' + (on ? '\u2605' : '\u2606') + '</span> ' + (on ? 'Сохранено' : 'Сохранить');
        } else if (r && r.data && r.data.login) {
          if (msg) { msg.textContent = 'Сначала войдите - перенаправляем'; }
          window.location.href = r.data.login;
          return;
        }
        if (msg) { msg.textContent = (r && r.data && r.data.msg) || ''; setTimeout(function () { msg.textContent = ''; }, 2600); }
      });
    });
  });

  document.querySelectorAll('[data-hod-access-op]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var out = document.querySelector('.acct-msg');
      btn.disabled = true;
      post({
        action: 'hod_access_op',
        op: btn.getAttribute('data-hod-access-op'),
        months: btn.getAttribute('data-months') || 1
      }, function (r) {
        btn.disabled = false;
        var text = (r && r.data && r.data.msg) || 'Не получилось';
        if (out) { out.textContent = text; out.className = 'acct-msg small ' + (r && r.success ? 'ok' : 'bad'); }
        if (r && r.success) { setTimeout(function () { window.location.reload(); }, 1100); }
      });
    });
  });
})();
