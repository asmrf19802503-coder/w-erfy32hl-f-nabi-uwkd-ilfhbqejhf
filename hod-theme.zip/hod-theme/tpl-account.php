<?php
/**
 * Template Name: Личный кабинет Pro
 * Доступ, сохранённые карточки, мои заявки ситуаций, экспорт, пауза и отмена.
 */
defined( 'ABSPATH' ) || exit;

/* Обработчики скачивания должны отрабатывать до вывода HTML. */
if ( isset( $_GET['hod_export_set'] ) && is_user_logged_in() && function_exists( 'hod_is_pro' ) && hod_is_pro() ) {
	$saved_ids = array_values( array_filter( array_map( 'absint', (array) get_user_meta( get_current_user_id(), 'hod_saved', true ) ) ) );
	if ( $saved_ids ) {
		$fmt = 'txt' === sanitize_key( wp_unslash( $_GET['hod_export_set'] ) ) ? 'txt' : 'md';
		nocache_headers();
		if ( 'txt' === $fmt ) {
			header( 'Content-Type: text/plain; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="hod-saved.txt"' );
			foreach ( $saved_ids as $sid ) {
				echo get_the_title( $sid ) . "\n" . str_repeat( '=', 60 ) . "\n\n";
				foreach ( hod_card_export_data( $sid ) as $k => $v ) { echo strtoupper( $k ) . "\n" . $v . "\n\n"; }
			}
		} else {
			header( 'Content-Type: text/markdown; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="hod-saved.md"' );
			echo "# Сохранённые карточки ХОД\n\nВыгружено: " . date_i18n( 'd.m.Y H:i' ) . "\n";
			foreach ( $saved_ids as $sid ) {
				echo "\n---\n\n## " . get_the_title( $sid ) . "\n\n";
				foreach ( hod_card_export_data( $sid ) as $k => $v ) { echo '### ' . $k . "\n\n" . $v . "\n\n"; }
			}
		}
		exit;
	}
}

$hod_pack_notice = '';
if ( isset( $_GET['hod_pack'] ) && is_user_logged_in() && function_exists( 'hod_is_pro' ) && hod_is_pro() ) {
	$pack_raw = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) wp_unslash( $_GET['hod_pack'] ) );
	$path     = WP_CONTENT_DIR . '/uploads/pro/' . strtolower( $pack_raw ) . '.zip';
	if ( is_readable( $path ) ) {
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . basename( $path ) . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		readfile( $path );
		exit;
	}
	$hod_pack_notice = 'Файл пака ' . esc_html( $pack_raw ) . ' ещё не загружен в wp-content/uploads/pro/. Загрузите архив - и кнопка заработает (INSTALL, разделы 17.3 и 18.4).';
}

get_header();

$uid   = get_current_user_id();
$me    = $uid ? wp_get_current_user() : null;
$until = $uid ? (string) get_user_meta( $uid, 'hod_access_until', true ) : '';
$level = $uid ? (string) get_user_meta( $uid, 'hod_access_level', true ) : '';
$paused = $uid && function_exists( 'hod_is_paused' ) ? hod_is_paused( $uid ) : false;
$active = $uid && $until && strtotime( $until ) > current_time( 'timestamp' ) && ! $paused;
$saved  = $uid ? array_values( array_filter( array_map( 'absint', (array) get_user_meta( $uid, 'hod_saved', true ) ) ) ) : array();
$days_left = $active ? max( 0, (int) ceil( ( strtotime( $until ) - current_time( 'timestamp' ) ) / DAY_IN_SECONDS ) ) : 0;
?>
<div class="wrap" style="padding-top:30px;padding-bottom:50px">
	<h1 style="font-size:32px">Личный кабинет</h1>

	<?php if ( ! $uid ) : ?>
		<div class="card pad" style="max-width:560px;margin-top:18px">
			<p class="lead">Войдите, чтобы увидеть доступ, сохранённые карточки и свои заявки ситуаций.</p>
			<p style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
				<a class="btn btn-p" href="<?php echo esc_url( wp_login_url( home_url( '/account/' ) ) ); ?>">Войти</a>
				<a class="btn btn-o" href="<?php echo esc_url( wp_registration_url() ); ?>">Создать аккаунт</a>
			</p>
			<p class="xs muted" style="margin-top:12px">Если вы оплатили, но аккаунта нет: доступ создаётся автоматически по email из платежа, письмо со ссылкой на вход приходит сразу после оплаты.</p>
		</div>
	<?php else : ?>

	<div class="grid g2" style="margin-top:20px;align-items:start">
		<div>
			<div class="card pad">
				<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
					<span class="badge <?php echo $active ? 'b-pro' : 'b-free'; ?>"><?php echo $active ? ( 'team' === $level ? 'Team' : 'Pro' ) : ( $paused ? 'Пауза' : 'Free' ); ?></span>
					<b style="font-size:18px"><?php echo esc_html( $me->user_email ); ?></b>
				</div>
				<?php if ( $active ) : ?>
					<p class="small muted" style="margin:10px 0 0">Доступ действует до <b><?php echo esc_html( date_i18n( 'd.m.Y', strtotime( $until ) ) ); ?></b> - осталось <?php echo (int) $days_left; ?> дн.</p>
				<?php elseif ( $paused ) : ?>
					<p class="small muted" style="margin:10px 0 0">Доступ на паузе до <b><?php echo esc_html( date_i18n( 'd.m.Y', strtotime( (string) get_user_meta( $uid, 'hod_paused_until', true ) ) ) ); ?></b>. Оплаченные дни перенесены.</p>
				<?php else : ?>
					<p class="small muted" style="margin:10px 0 0">Активного доступа нет. Free-слой доступен всегда: видео, ситуации, ошибки, приёмы и основные диалоги.</p>
				<?php endif; ?>
				<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
					<a class="btn btn-a btn-s" href="<?php echo esc_url( home_url( '/pro/#pay' ) ); ?>"><?php echo $active ? 'Продлить' : 'Открыть Pro - 390 ₽/мес'; ?></a>
					<?php if ( $active && ! $paused ) : ?>
						<button class="btn btn-o btn-s" data-hod-access-op="pause" data-months="1">Пауза на 1 мес.</button>
						<button class="btn btn-o btn-s" data-hod-access-op="cancel">Отключить напоминания</button>
					<?php elseif ( $paused ) : ?>
						<button class="btn btn-o btn-s" data-hod-access-op="resume">Снять паузу</button>
					<?php endif; ?>
					<?php if ( get_user_meta( $uid, 'hod_cancelled', true ) ) : ?>
						<button class="btn btn-o btn-s" data-hod-access-op="uncancel">Включить напоминания</button>
					<?php endif; ?>
				</div>
				<p class="xs muted" style="margin-top:10px">Отмена и пауза в один клик, без писем и обращений. Возврат в течение 14 дней - напишите на почту, указанную в футере.</p>
				<div class="acct-msg small" role="status" aria-live="polite"></div>
			</div>

			<div class="card pad" style="margin-top:16px">
				<b style="font-size:16px">Мои заявки ситуаций</b>
				<?php
				$q = new WP_Query( array(
					'post_type'      => 'hod_request',
					'post_status'    => array( 'private', 'publish', 'draft' ),
					'posts_per_page' => 20,
					'meta_query'     => array( array( 'key' => '_hod_email', 'value' => $me->user_email ) ),
					'no_found_rows'  => true,
				) );
				if ( $q->have_posts() ) :
					echo '<ul class="small" style="margin:10px 0 0;padding-left:18px">';
					while ( $q->have_posts() ) : $q->the_post();
						$st = (string) get_post_meta( get_the_ID(), '_hod_request_status', true );
						echo '<li style="margin-bottom:6px">' . esc_html( get_the_title() )
							. ' <span class="badge ' . ( 'готово' === $st ? 'b-free' : 'b-code' ) . '">' . esc_html( $st ? $st : 'в очереди' ) . '</span></li>';
					endwhile;
					echo '</ul>';
					wp_reset_postdata();
				else :
					echo '<p class="small muted" style="margin:10px 0 0">Пока пусто. Прислать реплику собеседника можно через форму «Прислать ситуацию» - подписчики Pro попадают в производство вне очереди.</p>';
				endif;
				?>
				<a class="btn btn-o btn-s" style="margin-top:12px" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a>
			</div>
		</div>

		<div>
			<div class="card pad">
				<b style="font-size:16px">Сохранённые карточки: <?php echo count( $saved ); ?></b>
				<?php if ( $saved ) : ?>
					<div class="grid g1" style="margin-top:12px">
					<?php
					$sq = new WP_Query( array( 'post_type' => 'situation', 'post__in' => $saved, 'posts_per_page' => 30, 'orderby' => 'post__in', 'no_found_rows' => true ) );
					while ( $sq->have_posts() ) : $sq->the_post();
						get_template_part( 'template-parts/card-situation', null, array( 'post' => get_post() ) );
					endwhile;
					wp_reset_postdata();
					?>
					</div>
					<?php if ( hod_is_pro() ) : ?>
						<p style="margin-top:14px"><a class="btn btn-o btn-s" href="<?php echo esc_url( add_query_arg( 'hod_export_set', 'md', home_url( '/account/' ) ) ); ?>">Выгрузить сохранённые в Markdown</a></p>
					<?php endif; ?>
				<?php else : ?>
					<p class="small muted" style="margin:10px 0 0">Нажмите «Сохранить» на карточке - она появится здесь и в вашем экспорте.</p>
					<a class="btn btn-o btn-s" style="margin-top:10px" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Открыть каталог</a>
				<?php endif; ?>
			</div>

			<?php if ( hod_is_pro() ) : ?>
			<div class="card pad" style="margin-top:16px">
				<b style="font-size:16px">Паки инструментов</b>
				<p class="small muted" style="margin:8px 0 12px">Файлы доступны, пока активен доступ Pro. Скачивание идёт через проверку доступа, прямые ссылки закрыты.</p>
				<?php
				$packs = array(
					array( 'PACK-FC', 'Первый контакт', '/wp-content/uploads/pro/pack-fc.zip' ),
					array( 'PACK-PR', 'Цена и скидка', '/wp-content/uploads/pro/pack-pr.zip' ),
					array( 'PACK-NG', 'Переговоры', '/wp-content/uploads/pro/pack-ng.zip' ),
					array( 'PACK-PS', 'Позиционирование', '/wp-content/uploads/pro/pack-ps.zip' ),
					array( 'PACK-MKT', 'Маркетинг-аудит', '/wp-content/uploads/pro/pack-mkt.zip' ),
					array( 'PACK-PM', 'Управление персоналом', '/wp-content/uploads/pro/pack-pm.zip' ),
				);
				echo '<div class="grid g2">';
				foreach ( $packs as $pk ) {
					echo '<div class="card pad" style="margin:0"><span class="badge b-code">' . esc_html( $pk[0] ) . '</span>'
						. '<div class="small" style="margin:6px 0 8px">' . esc_html( $pk[1] ) . '</div>'
						. '<a class="btn btn-o btn-s" href="' . esc_url( add_query_arg( 'hod_pack', $pk[0], home_url( '/account/' ) ) ) . '">Скачать</a></div>';
				}
				echo '</div>';
				?>
				<p class="xs muted" style="margin-top:10px">Если файл ещё не загружен на сервер, вы увидите сообщение об этом - значит, пак появится в ближайшем дайджесте.</p>
			</div>
			<?php else : ?>
			<div class="card pad" style="margin-top:16px;border-color:#FFD8C7;background:var(--accent-t)">
				<b style="font-size:16px">Что откроется с Pro</b>
				<ul class="small" style="margin:10px 0 12px;padding-left:18px">
					<li>Развилки диалога и тренажёр «выбери ответ» в каждой карточке</li>
					<li>Готовые формулировки и чек-листы подготовки</li>
					<li>6 паков инструментов и 2 расчётные таблицы xlsx</li>
					<li>Экспорт карточек в Markdown, TXT и PDF, скачивание MP4</li>
					<li>Категория «Управление персоналом» с правовой рамкой ТК РФ</li>
				</ul>
				<a class="btn btn-a btn-s" href="<?php echo esc_url( home_url( '/pro/' ) ); ?>">390 ₽/мес · первый месяц 99 ₽</a>
			</div>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( $hod_pack_notice ) : ?><div class="note" style="margin-top:18px"><?php echo esc_html( $hod_pack_notice ); ?></div><?php endif; ?>
	<?php endif; ?>
</div>
<?php get_footer(); ?>

