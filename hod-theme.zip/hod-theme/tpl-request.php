<?php /* Template Name: Прислать ситуацию */ defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap article" style="padding-top:30px;padding-bottom:48px;max-width:700px">
	<?php hod_breadcrumbs(); ?>
	<h1>Прислать ситуацию</h1>
	<p class="lead muted" style="font-size:17px;margin-top:12px">Опишите дословно, что сказал собеседник, - и в каком контексте. Такие заявки - главный источник новых карточек: мы разбираем их в ближайших выпусках и возвращаемся к вам со ссылкой.</p>
	<form class="card pad hod-form" data-hod-form="request" novalidate>
		<label>Реплика собеседника *</label>
		<textarea name="line" rows="2" required placeholder="Например: «Я работаю за двоих, а прибавки не было два года»"></textarea>
		<label>Контекст: кто, где, что уже произошло</label>
		<textarea name="context" rows="3" placeholder="Отрасль, размер компании, кто говорит, на какой стадии"></textarea>
		<label>Ваша роль</label>
		<input name="role" type="text" placeholder="РОП, CMO, HR, фаундер…">
		<label>Имя</label>
		<input name="name" type="text" placeholder="Как к вам обращаться">
		<label>Email (чтобы прислать ссылку на разбор)</label>
		<input name="email" type="email" placeholder="you@company.ru">
		<label style="display:flex;gap:8px;text-transform:none;letter-spacing:0;font-weight:500;font-size:13px"><input type="checkbox" name="consent" value="1" required style="width:auto"> Согласен на обработку персональных данных и на использование описания ситуации в библиотеке (в обезличенном виде)</label>
		<button class="btn btn-p" style="margin-top:14px;width:100%">Отправить ситуацию</button>
		<div class="form-msg" hidden></div>
	</form>
	<p class="xs muted" style="margin-top:14px">Не присылайте персональные данные сотрудников и клиентов, коммерческую тайну и записи звонков без согласия участников. Примеры в библиотеке всегда обезличены.</p>
</div>
<?php get_footer(); ?>
