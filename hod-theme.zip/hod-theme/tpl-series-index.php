<?php /* Template Name: Все серии */ defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap" style="padding-top:30px;padding-bottom:48px">
	<?php hod_breadcrumbs(); ?>
	<h1 style="font-size:34px">Серии библиотеки</h1>
	<p class="lead muted" style="font-size:17px;margin-top:12px;max-width:70ch">Каждая серия - это один рабочий контур: первый контакт, цена, позиционирование, люди. Внутри серии ситуации идут по порядку, цвет серии сквозной для ролика, карточки и навигации.</p>
	<div class="grid g3" style="margin-top:26px">
	<?php
	$terms = get_terms( array( 'taxonomy' => 'series', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
	if ( $terms && ! is_wp_error( $terms ) ) : foreach ( $terms as $s ) :
		$col = get_term_meta( $s->term_id, 'hod_color', true ); if ( ! $col ) { $col = '#1B4DFF'; }
		?>
		<a class="card scard" href="<?php echo esc_url( get_term_link( $s ) ); ?>" style="text-decoration:none;color:inherit">
			<div class="stripe" style="background:<?php echo esc_attr( $col ); ?>"></div>
			<div class="body">
				<div class="meta"><span class="seriesdot" style="background:<?php echo esc_attr( $col ); ?>"></span> <?php echo (int) $s->count; ?> ситуаций</div>
				<div class="q"><?php echo esc_html( $s->name ); ?></div>
				<?php if ( $s->description ) : ?><div class="small muted"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $s->description ), 20, '...' ) ); ?></div><?php endif; ?>
			</div>
			<div class="foot"><span class="badge b-free">Смотреть</span><span class="mono"><?php echo esc_html( strtoupper( $s->slug ) ); ?></span></div>
		</a>
	<?php endforeach; else : ?>
		<div class="note" style="grid-column:1/-1">Серии появятся после импорта карточек.</div>
	<?php endif; ?>
	</div>
	<div class="card pad" style="margin-top:30px;background:var(--mist)">
		<h3>Не нашли свою серию?</h3>
		<p class="small muted">Опишите ситуацию - добавим серию или разберём ситуацию в ближайшем выпуске.</p>
		<a class="btn btn-p btn-s" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a>
	</div>
</div>
<?php get_footer(); ?>
