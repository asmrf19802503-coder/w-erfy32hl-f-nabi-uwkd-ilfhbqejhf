<?php defined( 'ABSPATH' ) || exit; get_header(); ?>
<div class="wrap" style="padding:60px 20px;text-align:center">
	<div class="mono muted" style="font-size:13px;letter-spacing:.1em">404</div>
	<h1 style="font-size:34px;margin-top:10px">Такой ситуации в библиотеке пока нет</h1>
	<p class="muted" style="max-width:52ch;margin:14px auto 22px">Возможно, карточка переехала или ещё не опубликована. Поищите по реплике собеседника или предложите свою ситуацию - разберём.</p>
	<form class="searchbig" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="margin:0 auto 18px;max-width:520px">
		<input type="search" name="s" placeholder="Что сказал клиент?"><input type="hidden" name="post_type" value="situation"><button class="btn btn-p">Найти</button>
	</form>
	<p><a class="btn btn-o" href="<?php echo esc_url( home_url( '/catalog/' ) ); ?>">Открыть каталог</a> <a class="btn btn-p" href="<?php echo esc_url( home_url( '/podat-situaciyu/' ) ); ?>">Прислать ситуацию</a></p>
</div>
<?php get_footer(); ?>
