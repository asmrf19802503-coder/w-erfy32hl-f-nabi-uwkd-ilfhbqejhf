<?php defined( 'ABSPATH' ) || exit; ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#hod-content">Перейти к содержанию</a>
<div class="topbar">
	<div class="wrap topbar-in">
		<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true"><rect width="32" height="32" rx="8" fill="#1B4DFF"/><path d="M9 21.5L14.5 16L9 10.5" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="21" cy="16" r="2.6" fill="#FF5A1F"/></svg>
			<span><?php bloginfo( 'name' ); ?><small>библиотека ситуаций</small></span>
		</a>
		<nav class="navlinks" aria-label="Основная навигация">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1 ) );
			} else {
				echo '<a href="' . esc_url( home_url( '/catalog/' ) ) . '">Каталог</a>';
				echo '<a href="' . esc_url( home_url( '/series/' ) ) . '">Серии</a>';
				echo '<a href="' . esc_url( home_url( '/objections/' ) ) . '">Возражения</a>';
				echo '<a href="' . esc_url( home_url( '/method/' ) ) . '">Метод</a>';
			}
			?>
		</nav>
		<div class="spacer"></div>
		<form class="searchmini" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="border:0;padding:0;background:none">
			<label class="screen-reader-text" for="hod-s">Поиск по ситуациям</label>
			<input id="hod-s" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Что сказал клиент?" style="border:1px solid var(--line2);background:var(--mist);border-radius:999px;padding:8px 14px;font-size:13px;min-width:210px;font-family:var(--sans)">
			<input type="hidden" name="post_type" value="situation">
		</form>
		<?php if ( is_user_logged_in() ) : ?>
			<a class="btn btn-o btn-s" href="<?php echo esc_url( function_exists( 'hod_account_url' ) ? hod_account_url() : home_url( '/account/' ) ); ?>">Кабинет</a>
			<a class="btn btn-o btn-s" href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>">Выйти</a>
		<?php else : ?>
			<a class="btn btn-o btn-s" href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>">Войти</a>
		<?php endif; ?>
		<a class="btn btn-<?php echo hod_is_pro() ? 'o' : 'p'; ?> btn-s" href="<?php echo esc_url( hod_is_pro() && function_exists( 'hod_account_url' ) ? hod_account_url() : home_url( '/pro/' ) ); ?>"><?php echo hod_is_pro() ? 'Мой Pro' : 'Pro'; ?></a>
	</div>
</div>
<main id="hod-content">
