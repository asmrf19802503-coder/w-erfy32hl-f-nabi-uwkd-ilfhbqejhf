<?php
/**
 * Слой библиотеки: /origin/world/ и /origin/ru-cis/.
 * Использует общий шаблон каталога с фильтрами.
 */
get_template_part( 'archive', 'situation' );
